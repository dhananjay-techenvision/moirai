<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Tabs extends Model
{
    protected $table = 'tabs';
}
