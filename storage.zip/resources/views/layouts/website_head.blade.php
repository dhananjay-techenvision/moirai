<!-- google fonts -->
<link href="https://fonts.googleapis.com/css?family=Roboto:300,300i,400,400i,500,500i,700,700i,900" rel="stylesheet">

<link rel="stylesheet" href="{{asset('Website/css/vendor/bootstrap.min.css')}}" type="text/css" />
<link rel="stylesheet" href="{{asset('Website/css/vendor/bicon.min.css')}}" type="text/css" />
<link rel="stylesheet" href="{{asset('Website/css/vendor/flaticon.css')}}" type="text/css" />
<link rel="stylesheet" href="{{asset('Website/css/plugins/plyr.css')}}" type="text/css" />
<link rel="stylesheet" href="{{asset('Website/css/plugins/slick.min.css')}}" type="text/css" />

<link rel="stylesheet" href="{{asset('Website/css/plugins/nice-select.css')}}" type="text/css" />
<link rel="stylesheet" href="{{asset('Website/css/plugins/perfect-scrollbar.css')}}" type="text/css" />
<link rel="stylesheet" href="{{asset('Website/css/plugins/lightgallery.min.css')}}" type="text/css" />
<link rel="stylesheet" href="{{asset('Website/css/style.css')}}" type="text/css" />

