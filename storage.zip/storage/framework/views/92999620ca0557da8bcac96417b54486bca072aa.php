
<div class="col-12">
    <div class="card">
        <div class="card-body"> 
            <div class="col-12 text-right pb-2"> 
                
            </div>    
        <table id="datatable-buttons" class="table table-striped table-bordered dt-responsive nowrap text-center" style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                <thead>
                    <tr>
                        <th>No </th>
                        <th>User Name</th>
                        <th>Mobile</th>
                        <th>Email</th>
                        <th>Status</th>                            
                        <th>Action</th>  
                        <th></th>                  
                    </tr>
                </thead>

                <tbody>
                    
                    <?php $i = 1; ?>
                    <?php $__currentLoopData = $Users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($i++); ?></td>
                        <td><?php echo e($row->name); ?> <?php echo e($row->user_id); ?></td>                          
                        <td><?php echo e($row->phone); ?></td>   
                        <td><?php echo e($row->email); ?></td>                            
                        <td><?php if($row->status == 1): ?> Active <?php else: ?> De-Active <?php endif; ?></td>
                        
                       <td>
                       <?php
                         $deactive = 0;
                         $active = 1;
                         ?>
                         <?php if($row->status == 1): ?> <a href="<?php echo e(url('status-student/'.$row->id.'/'.$deactive)); ?>" class="btn btn-danger">Deactive</a><?php else: ?> <a href="<?php echo e(url('status-student/'.$row->id.'/'.$active)); ?>" class="btn btn-info">Active</a><?php endif; ?> </td>
                         <td>  </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   
                </tbody>
            </table>
        </div>
    </div>
</div>

<style>
    .dt-buttons
    {
        display:none!important;
    }
 </style>   
<!-- end col -->
<?php /**PATH D:\xampp\htdocs\final_moirah\resources\views/Admin/user_list.blade.php ENDPATH**/ ?>