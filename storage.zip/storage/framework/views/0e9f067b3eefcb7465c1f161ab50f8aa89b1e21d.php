
<div class="col-12">
    <div class="card">
        <div class="card-body">

            
            
            <div class="col-md-8 m-auto">
                      <?php
                        //   dd($answer);
                      ?>                 
                <form class="" action="<?php echo e(url('submit-answer')); ?>" method="POST">                        
                <?php echo csrf_field(); ?> 
                   <input type="hidden" name="question_id" value="<?php echo e($question->id); ?>">
                    <div class="form-group row">
                        <label class="col-sm-3 col-form-label">Question </label>
                        <div class="col-sm-9">
                            <div class="form-group">                            
                                <div>
                                    <textarea  class="form-control" rows="3" name="question" placeholder="Enter Question" readonly><?php echo e($question->question); ?></textarea>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php if($answer): ?>
                        <?php $__currentLoopData = $answer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="form-group row">
                            <label class="col-md-3 col-form-label">Answer  </label>    
                            <input type="hidden" name="answer_id[]" value="<?php echo e($item->id); ?>">                   
                            <div class="col-md-9">
                                <input type="text" class="form-control" name="answer[]" value="<?php echo e($item->answer); ?>"  placeholder="Enter Answer "/>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                    <div class="form-group row">
                        <label class="col-sm-3 col-form-label">Correct Answer</label>
                        <div class="col-sm-9">
                            <select class="form-control" name="correct_answer">    
                            <?php for($i=0; $i < $question->choice_count; $i++) {  ?>                                
                                <option value="<?php echo e($i+1); ?>"   <?php if($i+1 == $question->correct_answer): ?>selected <?php endif; ?>><?php echo e($i+1); ?></option>
                            <?php  }  ?>                              
                            </select>
                        </div>
                    </div>
                    
                    <div class="form-group row">
                        <label class="col-sm-3 col-form-label">Status</label>
                        <div class="col-sm-9">
                            <select class="form-control" name="status">                                    
                                <option value="1">Active</option>
                                <option value="0">De-Active</option>                                     
                            </select>
                        </div>
                    </div>
                    <div class="form-group text-center mt-5">
                        <div>
                            <button type="reset" class="btn btn-secondary waves-effect m-l-5">
                            Cancel
                            </button>
                            <button type="submit" class="btn btn-primary waves-effect waves-light">
                            Submit
                            </button>
                        </div>

                        
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<!-- end col -->


<?php /**PATH D:\xampp\htdocs\new_zlearn\resources\views/Admin/components/question/admin_edit_answer.blade.php ENDPATH**/ ?>