
  

<!--[if lt IE 9]>
<script src="js/html5shiv.js"></script>
<![endif]-->

<!-- CSS Files
================================================== -->
<link rel="stylesheet" href="<?php echo e(asset('/website/css/bootstrap.min.css')); ?>" type="text/css">
<link rel="stylesheet" href="<?php echo e(asset('/website/css/bootstrap-grid.min.css')); ?>" type="text/css">
<link rel="stylesheet" href="<?php echo e(asset('/website/css/bootstrap-reboot.min.css')); ?>" type="text/css">
<link rel="stylesheet" href="<?php echo e(asset('/website/css/animate.css')); ?>" type="text/css">
<link rel="stylesheet" href="<?php echo e(asset('/website/css/owl.carousel.css')); ?>" type="text/css">
<link rel="stylesheet" href="<?php echo e(asset('/website/css/magnific-popup.css')); ?>" type="text/css">
<link rel="stylesheet" href="<?php echo e(asset('/website/css/style.css')); ?>" type="text/css">

<!-- background -->
<link rel="stylesheet" href="<?php echo e(asset('/website/css/bg.css')); ?>" type="text/css">

<!-- color scheme -->
<link rel="stylesheet" id="colors" href="<?php echo e(asset('/website/css/colors/orange.css')); ?>" type="text/css">


<?php /**PATH D:\xampp\htdocs\new_zlearn\resources\views/layouts/website_head.blade.php ENDPATH**/ ?>