
<div class="col-12">
    <div class="card">
        <div class="card-body">

            
            
            <div class="col-md-8 m-auto">                                       
                <form class="" action="<?php echo e(url('submit-blogs')); ?>" method="POST" enctype="multipart/form-data">                        
                <?php echo csrf_field(); ?> 
                <input type="hidden" name="blog_id" value="<?php echo e($blogs->id); ?>">
                    <div class="form-group row">
                        <label class="col-sm-3 col-form-label">Title</label>
                        <div class="col-sm-9">
                            <input type="text" class="form-control" name="blog_title"  placeholder="Enter Title" value="<?php echo e($blogs->blog_title); ?>" required/>
                        </div>
                    </div>   
                    <?php
                        // $date  =  $blogs->blog_date->format('Y-m-d');
                        $date1 = $blogs->updated_at->format('Y-m-d');
                    ?>
                    <div class="form-group row">
                        <label class="col-sm-3 col-form-label">Blog Date</label>
                        <div class="col-sm-9">
                            <input type="date" class="form-control" name="blog_date" value="<?php echo e($blogs->blog_date); ?>"/>
                        </div>
                    </div>  
                    
                    <div class="form-group row">
                        <label class="col-sm-3 col-form-label">Blog Content</label>
                        <div class="col-sm-9">
                            <div class="form-group">                            
                                <div>
                                    <textarea  class="form-control" rows="3" name="blog_content" placeholder="Enter Content"><?php echo e($blogs->blog_content); ?></textarea>
                                </div>
                            </div>
                        </div>
                    </div>


                            <?php if($blogs->blog_images): ?>
                            <div class="form-group row ">
                                <label class="form-label col-md-3 p-2">Preview</label>
                                <div class=" col-md-9">                                  
                                   <img class="document_img" src="<?php echo e(asset($blogs->blog_images)); ?>" alt="" width="80" height="80">
                                </div>                                
                            </div>
                            <?php endif; ?>

                    <div class="form-group row">
                        <label class="col-md-3 col-form-label">Image </label>
                        <div class="col-md-9">
                            <input type="file" name="new_blog_image">
                        </div>
                    </div>

                    <div class="form-group row">
                        <label class="col-sm-3 col-form-label">Status</label>
                        <div class="col-sm-9">
                            <select class="form-control" name="status">                                    
                                <option value="1" <?php if($blogs->status == '1'): ?> selected <?php endif; ?>>Active</option>
                                <option value="0" <?php if($blogs->status == '0'): ?> selected <?php endif; ?>>De-Active</option>                                     
                            </select>
                        </div>
                    </div>
                    <div class="form-group text-center mt-5">
                        <div>
                            <button type="submit" class="btn btn-primary waves-effect waves-light">
                            Update
                            </button>
                           
                        </div>

                        <div class="any_message mt-3">
                            <?php if($errors->any()): ?>
                                <div class="alert alert-danger">
                                    <ul>
                                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li><?php echo e($error); ?></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                        </button>
                                    </ul>
                                </div>
                            <?php endif; ?>
                            <?php if(session()->has('alert-danger')): ?>
                                <div class="alert alert-danger">
                                    <?php echo e(session()->get('alert-danger')); ?>

                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                            <?php endif; ?>
                                <?php if(session()->has('alert-success')): ?>
                                <div class="alert alert-success">
                                    <?php echo e(session()->get('alert-success')); ?>

                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<!-- end col -->


<?php /**PATH D:\xampp\htdocs\final_moirah\resources\views/Admin/components/edit_blogs.blade.php ENDPATH**/ ?>