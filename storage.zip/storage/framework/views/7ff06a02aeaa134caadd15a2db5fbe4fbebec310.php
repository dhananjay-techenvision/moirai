<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
        <title>Linea - Creative Website Template</title>
        <?php echo $__env->make('layouts.student_head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo toastr_css(); ?>
  </head>

    <?php echo $__env->yieldContent('body'); ?>
    <?php echo $__env->make('layouts.student_footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo toastr_js(); ?>
    <?php echo app('toastr')->render(); ?>

</html><?php /**PATH D:\xampp\htdocs\new_zlearn\resources\views/layouts/website.blade.php ENDPATH**/ ?>