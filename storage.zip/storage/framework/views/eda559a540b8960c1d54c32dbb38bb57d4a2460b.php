
        <?php echo $__env->yieldContent('css'); ?>

        <!-- App css -->
        <link href="<?php echo e(URL::asset('/css/bootstrap-dark.min.css')); ?>" id="bootstrap-dark" rel="stylesheet" type="text/css" />
        <link href="<?php echo e(URL::asset('/css/bootstrap.min.css')); ?>" id="bootstrap-light" rel="stylesheet" type="text/css" />
        <link href="<?php echo e(URL::asset('/css/icons.min.css')); ?>" rel="stylesheet" type="text/css" />
        <link href="<?php echo e(URL::asset('/css/app-rtl.min.css')); ?>" id="app-rtl" rel="stylesheet" type="text/css" />
        <link href="<?php echo e(URL::asset('/css/app-dark.min.css')); ?>" id="app-dark" rel="stylesheet" type="text/css" />
        <link href="<?php echo e(URL::asset('/css/app.min.css')); ?>" id="app-light" rel="stylesheet" type="text/css" /><?php /**PATH D:\xampp\htdocs\new_zlearn\resources\views/layouts/head.blade.php ENDPATH**/ ?>