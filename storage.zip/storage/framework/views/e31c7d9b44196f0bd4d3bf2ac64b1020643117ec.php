<div class="col-12">
    <div class="card">
        <div class="card-body">   
            <form class="" action="<?php echo e(url('view-test-question')); ?>" method="POST">                        
                <?php echo csrf_field(); ?> 
            <div class="col-md-8 m-auto">
                    <div class="form-group row">
                        <label class="col-sm-3 col-form-label">Select Test</label>
                        <div class="col-sm-9">
                            <select class="form-control" name="test_id" required>
                                <option value="">Select Test</option>
                                <?php $__currentLoopData = $tests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                    <option value="<?php echo e($r->id); ?>"><?php echo e($r->test_name); ?></option> 
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
            </div>

            <div class="form-group text-center mt-5">
                <div>                        
                    <button type="submit" class="btn btn-primary waves-effect waves-light">
                    Find Question
                    </button>
                   
                </div>
            </div>

        </form>
        </div>
    </div>
</div>
<!-- end col -->


<div class="col-12">
<div class="card">
    
    <div class="card-body"> 
        <div class="col-12 text-right pb-2">
        </div>    
    <table id="table-search" class="table table-striped table-bordered dt-responsive nowrap text-center" style="border-collapse: collapse; border-spacing: 0; width: 100%;">
            
        </table>
    </div>
</div>
</div>



<style>
.dt-buttons
{
    display:none!important;
}
</style>   
<!-- end col --><?php /**PATH D:\xampp\htdocs\new_zlearn\resources\views/Admin/components/question/show_test_question.blade.php ENDPATH**/ ?>