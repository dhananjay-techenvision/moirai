<div class="preloader">
	<div class="sk-chase">
		<div class="sk-chase-dot"></div>
		<div class="sk-chase-dot"></div>
		<div class="sk-chase-dot"></div>
		<div class="sk-chase-dot"></div>
		<div class="sk-chase-dot"></div>
		<div class="sk-chase-dot"></div>
	</div>

	<!-- <div class="sk-bounce">
<div class="sk-bounce-dot"></div>
<div class="sk-bounce-dot"></div>
</div> -->

	<!-- More spinner examples at https://github.com/tobiasahlin/SpinKit/blob/master/examples.html -->
</div>

<!-- Drawer Layout -->

<div class="mdk-drawer-layout js-mdk-drawer-layout"
	 data-push
	 data-responsive-width="992px">
	<div class="mdk-drawer-layout__content page-content">

		<!-- Header -->

		<!-- Navbar -->

		<div class="navbar navbar-expand pr-0 navbar-light border-bottom-2"
			 id="default-navbar"
			 data-primary>

			<!-- Navbar Toggler -->

			<button class="navbar-toggler w-auto mr-16pt d-block d-lg-none rounded-0"
					type="button"
					data-toggle="sidebar">
				<span class="material-icons">short_text</span>
			</button>

			<!-- // END Navbar Toggler -->

			<!-- Navbar Brand -->

			<a href="index.html"
			   class="navbar-brand mr-16pt d-lg-none">

				<span class="avatar avatar-sm navbar-brand-icon mr-0 mr-lg-8pt">

					<span class="avatar-title rounded bg-primary"><img src ="<?php echo e(asset('Student/images/illustration/student/128/white.svg')); ?>"
							 alt="logo"
							 class="img-fluid" /></span>
				</span>

				<span class="d-none d-lg-block">Luma</span>
			</a>

			<!-- // END Navbar Brand -->

			<span class="d-none d-md-flex align-items-center mr-16pt">

				<span class="avatar avatar-sm mr-12pt">

					<span class="avatar-title rounded navbar-avatar"><i class="material-icons">opacity</i></span>

				</span>

				
			</span>

			<div class="flex"></div>

			<!-- Switch Layout -->

			

			<!-- // END Switch Layout -->

			<!-- Navbar Menu -->

			<div class="nav navbar-nav flex-nowrap d-flex mr-16pt">

				<!-- Notifications dropdown -->
				
				<!-- // END Notifications dropdown -->

				<!-- Notifications dropdown -->
				
				<!-- // END Notifications dropdown -->

				<div class="nav-item dropdown">
					<a href="#"
					   class="nav-link d-flex align-items-center dropdown-toggle"
					   data-toggle="dropdown"
					   data-caret="false">

						<span class="avatar avatar-sm mr-8pt2">

							<span class="avatar-title rounded-circle bg-primary"><i class="material-icons">account_box</i></span>

						</span>

					</a>
					<div class="dropdown-menu dropdown-menu-right">
						<div class="dropdown-header"><strong>Account</strong></div>
						<a class="dropdown-item"
						   href="edit-account.html">Edit Account</a>
						
						<a class="dropdown-item"
						   href="<?php echo e(url('/logout')); ?>">Logout</a>
					</div>
				</div>
			</div>

			<!-- // END Navbar Menu -->

		</div>

		<!-- // END Navbar -->

		<!-- // END Header --><?php /**PATH D:\xampp\htdocs\new_zlearn\resources\views/layouts/student_navbar.blade.php ENDPATH**/ ?>