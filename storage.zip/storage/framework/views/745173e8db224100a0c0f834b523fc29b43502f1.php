
<!-- build:js scripts/app.min.js -->
<!-- jQuery -->
<script src="<?php echo e(URL::asset('Website/js/vendor/jquery-3.6.0.min.js')); ?>"></script>

<!-- Bootstrap -->
  <script src="<?php echo e(URL::asset('Website/js/vendor/modernizr-3.6.0.min.js')); ?>"></script>
  <script src="<?php echo e(URL::asset('Website/js/vendor/bootstrap.bundle.min.js')); ?>"></script>
<!-- core -->
  <script src="<?php echo e(URL::asset('Website/js/plugins/slick.min.js')); ?>"></script>
  <script src="<?php echo e(URL::asset('Website/js/plugins/nice-select.min.js')); ?>"></script>
  <script src="<?php echo e(URL::asset('Website/js/plugins/plyr.min.js')); ?>"></script>
  <script src="<?php echo e(URL::asset('Website/js/plugins/perfect-scrollbar.min.js')); ?>"></script>
  <script src="<?php echo e(URL::asset('Website/js/plugins/lightgallery-all.min.js')); ?>"></script>
  <script src="<?php echo e(URL::asset('Website/js/plugins/imagesloaded.pkgd.min.js')); ?>"></script>

  <script src="<?php echo e(URL::asset('Website/js/plugins/isotope.pkgd.min.js')); ?>"></script>
  <script src="<?php echo e(URL::asset('Website/js/main.js')); ?>"></script>

  
  <script src="<?php echo e(asset('js/share.js')); ?>"></script>
<!-- endbuild --><?php /**PATH D:\xampp\htdocs\final_moirah\resources\views/layouts/website_footer.blade.php ENDPATH**/ ?>