
<div class="col-12">
    <div class="card">
        <div class="card-body">

            
            
            <div class="col-md-8 m-auto">
                                       
                <form class="" action="<?php echo e(url('submit-test')); ?>" method="POST">                        
                <?php echo csrf_field(); ?> 

                    <input type="hidden" name="test_id" value="<?php echo e($test->id); ?>">
                    <div class="form-group row">
                        <label class="col-sm-3 col-form-label">Test Type</label>
                        <div class="col-sm-9">
                            <select class="form-control" name="test_type_id" required>
                                <option value="">Select Test Type</option>
                                <?php $__currentLoopData = $test_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                    <option value="<?php echo e($r->id); ?>" <?php if($r->id == $test->test_type_id): ?>selected <?php endif; ?> ><?php echo e($r->test_type_name); ?></option> 
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>


                    <div class="form-group row">
                        <label class="col-sm-3 col-form-label">Types Of Test </label>
                        <div class="col-sm-9">
                            <select class="form-control" name="test_name_id" required>
                                <option value="">Select Types Of Test</option>
                                <?php $__currentLoopData = $test_name; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                    <option value="<?php echo e($r->id); ?>" <?php if($r->id == $test->test_name_id): ?>selected <?php endif; ?> ><?php echo e($r->test_name); ?></option> 
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label class="col-sm-3 col-form-label">Test Name</label>
                        <div class="col-sm-9">
                            <input type="text" class="form-control" name="test_name" placeholder="Enter Test Name" value="<?php echo e($test->test_name); ?>" required/>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label class="col-sm-3 col-form-label">General Directions </label>
                        <div class="col-sm-9">
                            <div class="form-group">                            
                                <div>
                                    <textarea  class="form-control" rows="3" name="test_instruction" placeholder="General Directions"><?php echo e($test->test_instruction); ?></textarea>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label class="col-sm-3 col-form-label">Test Instructions </label>
                        <div class="col-sm-9">
                            <div class="form-group">                            
                                <div>
                                    <textarea  class="form-control" rows="3" name="description" placeholder="Test Instructions"><?php echo e($test->description); ?></textarea>
                                </div>
                            </div>
                        </div>
                    </div>

                    <?php
                        $test_college= DB::table("test_college")->where("test_id",$test->id)->get();
                        // dd($test_college);
                    ?>

                    <div class="form-group row">
                        <label class="control-label col-sm-3"> Select College</label>
                        <div class="col-sm-9">
                            <select class="select2 form-control select2-multiple" multiple="multiple" name="college_id[]" data-placeholder="Choose ...">
                                <?php $__currentLoopData = $college; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                    <option value="<?php echo e($r->id); ?>" <?php $__currentLoopData = $test_college; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php echo e($list->college_id == $r->id ? 'selected': ''); ?>   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>><?php echo e($r->college_name); ?></option> 
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>

                <?php
                    $test_course= DB::table("test_course")->where("test_id",$test->id)->get();                    
                ?>

                    <div class="form-group row">
                        <label class="control-label col-sm-3"> Select Course</label>
                        <div class="col-sm-9">
                            <select class="select2 form-control select2-multiple" multiple="multiple" name="course_id[]" data-placeholder="Choose ...">
                                <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                    <option value="<?php echo e($r->id); ?>" <?php $__currentLoopData = $test_course; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php echo e($list->course_id == $r->id ? 'selected': ''); ?>   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> ><?php echo e($r->course_name); ?></option> 
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>


                    <?php
                        $test_branch= DB::table("test_branch")->where("test_id",$test->id)->get();                    
                    ?>

                    <div class="form-group row">
                        <label class="control-label col-sm-3"> Select Branch</label>
                        <div class="col-sm-9">
                            <select class="select2 form-control select2-multiple" multiple="multiple" name="branch_id[]" data-placeholder="Choose ...">
                                <?php $__currentLoopData = $branches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                    <option value="<?php echo e($r->id); ?>" <?php $__currentLoopData = $test_branch; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php echo e($list->branch_id == $r->id ? 'selected': ''); ?>   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>><?php echo e($r->branch_name); ?></option> 
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>                   

                    

                    <?php
                        $test_semester= DB::table("test_semester")->where("test_id",$test->id)->get();
                        // dd($test_semester);
                    ?>

                    
                    <div class="form-group row" style="display: none">
                        <label class="control-label col-sm-3"> Select Semester</label>
                        <div class="col-sm-9">
                            <select class="select2 form-control select2-multiple" multiple="multiple" name="old_semester_id[]" data-placeholder="Choose ...">
                                <?php $__currentLoopData = $semisters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                    <option value="<?php echo e($r->id); ?>" <?php $__currentLoopData = $test_semester; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php echo e($list->semester_id == $r->id ? 'selected': ''); ?>   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>><?php echo e($r->semister_name); ?></option> 
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label class="control-label col-sm-3"> Select Semester</label>
                        <div class="col-sm-9">
                            <select class="select2 form-control select2-multiple" multiple="multiple" name="semester_id[]" data-placeholder="Choose ...">
                                <?php $__currentLoopData = $semisters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                    <option value="<?php echo e($r->id); ?>" <?php $__currentLoopData = $test_semester; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php echo e($list->semester_id == $r->id ? 'selected': ''); ?>   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>><?php echo e($r->semister_name); ?></option> 
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label class="col-sm-3 col-form-label">Training Program</label>
                        <div class="col-sm-9">
                            <select class="form-control" name="program_name_id" required>
                                <option value="">Select Training Program</option>
                                <?php $__currentLoopData = $program_names; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                    <option value="<?php echo e($r->id); ?>" <?php if($r->id == $test->program_name_id): ?>selected <?php endif; ?> ><?php echo e($r->program_name); ?></option> 
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>

                    <?php
                        $test_tb_section= DB::table("test_tb_section")->where("test_id",$test->id)->get();                    
                    ?>

                    <div class="form-group row">
                        <label class="control-label col-sm-3"> Select Section</label>
                        <div class="col-sm-9">
                            <select class="select2 form-control select2-multiple" id="test_section_id" multiple="multiple" name="test_section_id[]" data-placeholder="Choose ..." required>
                                <?php $__currentLoopData = $test_section; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                    <option value="<?php echo e($r->id); ?>" <?php $__currentLoopData = $test_tb_section; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php echo e($list->test_section_id == $r->id ? 'selected': ''); ?>   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>><?php echo e($r->test_section_name); ?></option> 
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>


                    <?php
                        $test_subject= DB::table("test_subject")->where("test_id",$test->id)->get();                    
                    ?>

                    <div class="form-group row">
                        <label class="control-label col-sm-3"> Select Subject</label>
                        <div class="col-sm-9">
                            <select class="select2 form-control select2-multiple" id="test_subject_id" multiple="multiple" name="subject_id[]" data-placeholder="Choose ..." required>
                                <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                    <option value="<?php echo e($r->id); ?>" <?php $__currentLoopData = $test_subject; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php echo e($list->subject_id == $r->id ? 'selected': ''); ?>   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> ><?php echo e($r->subject_name); ?></option> 
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                
                   

                    <div class="form-group row">
                        <label class="col-md-3 col-form-label">Question Pattern</label>
                        <div class="col-md-9">
                            <select class="form-control" name="question_pattern" >
                                <option value="">Select Question Pattern</option>
                                <?php $__currentLoopData = $question_pattern; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                    <option value="<?php echo e($r->id); ?>" <?php if($r->id == $test->question_pattern): ?>selected <?php endif; ?> ><?php echo e($r->question_pattern_name); ?></option> 
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>

                    

                    <div class="form-group row">
                        <label class="col-sm-3 col-form-label">Total Question</label>
                        <div class="col-sm-9">
                            <input type="text" class="form-control" name="total_question"  placeholder="Enter Total Question" value="<?php echo e($test->total_question); ?>" required/>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label class="col-sm-3 col-form-label">Total Marks</label>
                        <div class="col-sm-9">
                            <input type="text" class="form-control" name="total_marks"  placeholder="Enter Total Marks" value="<?php echo e($test->total_marks); ?>" required/>
                        </div>
                    </div>

                    

                    <div class="form-group row">
                        <label class="col-sm-3 col-form-label">Test Duration</label>
                        <div class="col-sm-4">
                            <input type="number" class="form-control" name="hours"  placeholder="Enter hours" value="<?php echo e($test->hours); ?>" required/>
                        </div>
                        <div class="col-sm-4">
                            <input type="number" class="form-control" name="minute"  placeholder="Enter minute" value="<?php echo e($test->minute); ?>" required/>
                        </div>
                    </div>

                    

                    <div class="form-group row">
                        <label class="col-sm-3 col-form-label">Status</label>
                        <div class="col-sm-9">
                            <select class="form-control" name="status">                                    
                                <option value="1">Active</option>
                                <option value="0">De-Active</option>                                     
                            </select>
                        </div>
                    </div>
                    <div class="form-group text-center mt-5">
                        <div>
                            <button type="reset" class="btn btn-secondary waves-effect m-l-5">
                            Cancel
                            </button>
                            <button type="submit" class="btn btn-primary waves-effect waves-light">
                            Submit
                            </button>
                           
                        </div>

                        <div class="any_message mt-3">
                            <?php if($errors->any()): ?>
                                <div class="alert alert-danger">
                                    <ul>
                                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li><?php echo e($error); ?></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                        </button>
                                    </ul>
                                </div>
                            <?php endif; ?>
                            <?php if(session()->has('alert-danger')): ?>
                                <div class="alert alert-danger">
                                    <?php echo e(session()->get('alert-danger')); ?>

                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                            <?php endif; ?>
                                <?php if(session()->has('alert-success')): ?>
                                <div class="alert alert-success">
                                    <?php echo e(session()->get('alert-success')); ?>

                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<!-- end col -->


<?php /**PATH D:\xampp\htdocs\new_zlearn\resources\views/Admin/components/edit_test.blade.php ENDPATH**/ ?>