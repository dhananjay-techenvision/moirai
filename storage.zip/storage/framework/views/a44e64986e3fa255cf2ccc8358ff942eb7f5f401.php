<!-- ========== Left Sidebar Start ========== -->
<div class="vertical-menu">

    <div class="h-100">

        <div class="user-wid text-center py-4">
            <div class="user-img">
                <img src="<?php echo e(asset('images/users/avatar-2.jpg')); ?>" alt="" class="avatar-md mx-auto rounded-circle">
            </div>

            <div class="mt-3">

                <a href="#" class="text-dark font-weight-medium font-size-16"><?php echo e(Auth::user()->name); ?></a>
                <p class="text-body mt-1 mb-0 font-size-13">Admin </p>

            </div>
        </div>

        <!--- Sidemenu -->
        <div id="sidebar-menu">
            <!-- Left Menu Start -->
            <ul class="metismenu list-unstyled" id="side-menu">
                <li class="menu-title">Menu</li>

                <li>
                    <a href="javascript: void(0);" class="has-arrow waves-effect">
                        <i class="mdi mdi-map-marker-outline"></i>
                        <span>Users</span>
                    </a>
                    <ul class="sub-menu" aria-expanded="false">
                        <li><a href="<?php echo e(url('admin-list')); ?>">Admin list</a></li> 
                        <li><a href="<?php echo e(url('user-list')); ?>">Student list</a></li>   
                        
                    </ul>
                </li>
                <li>
                    <a href="javascript: void(0);" class="has-arrow waves-effect">
                        <i class="mdi mdi-map-marker-outline"></i>
                        <span>Master Pages</span>
                    </a>
                    <ul class="sub-menu" aria-expanded="false">                         
                        
                        <li><a href="<?php echo e(url('view-college')); ?>">View College</a></li>
                        <li><a href="<?php echo e(url('view-course')); ?>">View Course</a></li>
                        <li><a href="<?php echo e(url('view-branch')); ?>">View Branch</a></li>
                        <li><a href="<?php echo e(url('view-semister')); ?>">View Semester</a></li>
                                                
                        <li><a href="<?php echo e(url('view-subject')); ?>"> View Subject</a></li>
                        <li><a href="<?php echo e(url('view-chapter')); ?>">View Chapter</a></li>                        
                        <li><a href="<?php echo e(url('view-test-type')); ?>">View Test Type</a></li> 
                        <li><a href="<?php echo e(url('view-test-name')); ?>">View Test Name</a></li>                        
                        <li><a href="<?php echo e(url('view-question-level')); ?>">View Level</a></li>                        
                        <li><a href="<?php echo e(url('view-test-section')); ?>">View Test Section</a></li>                        
                        <li><a href="<?php echo e(url('view-program-name')); ?>">View Program Name</a></li>                        

                        
                    </ul>
                </li>

                <li>
                    <a href="javascript: void(0);" class="has-arrow waves-effect">
                        <i class="mdi mdi-map-marker-outline"></i>
                        <span>Manage Questions</span>
                    </a>
                    <ul class="sub-menu" aria-expanded="false">                        
                        <li><a href="<?php echo e(url('view-question')); ?>"> View Question</a></li>                        
                    </ul>
                </li>

                <li>
                    <a href="javascript: void(0);" class="has-arrow waves-effect">
                        <i class="mdi mdi-map-marker-outline"></i>
                        <span>Manage Test</span>
                    </a>
                    <ul class="sub-menu" aria-expanded="false">                        
                        <li><a href="<?php echo e(url('view-test')); ?>"> View Test</a></li>   
                        <li><a href="<?php echo e(url('manage-test-question')); ?>"> Manage Test Question</a></li>
                        <li><a href="<?php echo e(url('view-test-question')); ?>"> View Test Question</a></li>                      
                    </ul>
                </li>

                <li>
                    <a href="javascript: void(0);" class="has-arrow waves-effect">
                        <i class="mdi mdi-map-marker-outline"></i>
                        <span>Manage Material</span>
                    </a>
                    <ul class="sub-menu" aria-expanded="false">                        
                        <li><a href="<?php echo e(url('view-material')); ?>"> View Material</a></li>                                              
                    </ul>
                </li>
                

            </ul>
        </div>
        <!-- Sidebar -->
    </div>
</div>
<!-- Left Sidebar End --><?php /**PATH D:\xampp\htdocs\new_zlearn\resources\views/layouts/sidebar.blade.php ENDPATH**/ ?>