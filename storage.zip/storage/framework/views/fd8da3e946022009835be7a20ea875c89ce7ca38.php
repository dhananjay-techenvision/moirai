
<div class="col-12">
    <div class="card">
        <div class="card-body">

            
            
            <div class="col-md-8 m-auto">
                                       
                <form class="" action="<?php echo e(url('submit-test')); ?>" method="POST">                        
                <?php echo csrf_field(); ?> 

                    <div class="form-group row">
                        <label class="col-sm-3 col-form-label">Test Type</label>
                        <div class="col-sm-9">
                            <select class="form-control" name="test_type_id" required>
                                <option value="">Select Test Type</option>
                                <?php $__currentLoopData = $test_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                    <option value="<?php echo e($r->id); ?>"><?php echo e($r->test_type_name); ?></option> 
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>


                    <div class="form-group row">
                        <label class="col-sm-3 col-form-label">Types Of Test </label>
                        <div class="col-sm-9">
                            <select class="form-control" name="test_name_id" required>
                                <option value="">Select Types Of Test</option>
                                <?php $__currentLoopData = $test_name; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                    <option value="<?php echo e($r->id); ?>"><?php echo e($r->test_name); ?></option> 
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label class="col-sm-3 col-form-label">Test Name</label>
                        <div class="col-sm-9">
                            <input type="text" class="form-control" name="test_name" required placeholder="Enter Test Name" required/>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label class="col-sm-3 col-form-label">General Directions </label>
                        <div class="col-sm-9">
                            <div class="form-group">                            
                                <div>
                                    <textarea  class="form-control" rows="3" name="test_instruction" placeholder="General Directions"></textarea>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label class="col-sm-3 col-form-label">Test Instructions </label>
                        <div class="col-sm-9">
                            <div class="form-group">                            
                                <div>
                                    <textarea  class="form-control" rows="3" name="description" placeholder="Test Instructions"></textarea>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label class="control-label col-sm-3"> Select College</label>
                        <div class="col-sm-9">
                            <select class="select2 form-control select2-multiple" multiple="multiple" name="college_id[]" data-placeholder="Choose ...">
                                <?php $__currentLoopData = $college; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                    <option value="<?php echo e($r->id); ?>"><?php echo e($r->college_name); ?></option> 
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label class="control-label col-sm-3"> Select Course</label>
                        <div class="col-sm-9">
                            <select class="select2 form-control select2-multiple" multiple="multiple" name="course_id[]" data-placeholder="Choose ...">
                                <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                    <option value="<?php echo e($r->id); ?>"><?php echo e($r->course_name); ?></option> 
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label class="control-label col-sm-3"> Select Branch</label>
                        <div class="col-sm-9">
                            <select class="select2 form-control select2-multiple" multiple="multiple" name="branch_id[]" data-placeholder="Choose ...">
                                <?php $__currentLoopData = $branches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                    <option value="<?php echo e($r->id); ?>"><?php echo e($r->branch_name); ?></option> 
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>                   

                     <div class="form-group row">
                        <label class="control-label col-sm-3">Select Semester</label>
                        <div class="col-sm-9">
                            <select class="select2 form-control select2-multiple" multiple="multiple" name="semester_id[]" data-placeholder="Choose ...">
                                <?php $__currentLoopData = $semisters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                    <option value="<?php echo e($r->id); ?>"><?php echo e($r->semister_name); ?></option> 
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>

                    

                    <div class="form-group row">
                        <label class="col-sm-3 col-form-label">Training Program</label>
                        <div class="col-sm-9">
                            <select class="form-control" name="program_name_id" required>
                                <option value="">Select Training Program</option>
                                <?php $__currentLoopData = $program_names; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                    <option value="<?php echo e($r->id); ?>"><?php echo e($r->program_name); ?></option> 
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>

                    


                    


                    <div class="form-group row">
                        <label class="control-label col-sm-3"> Select Section</label>
                        <div class="col-sm-9">
                            <select class="select2 form-control select2-multiple" id="test_section_id" multiple="multiple" name="test_section_id[]" data-placeholder="Choose ..." required>
                                <?php $__currentLoopData = $test_section; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                    <option value="<?php echo e($r->id); ?>"><?php echo e($r->test_section_name); ?></option> 
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>


                    <div class="form-group row">
                        <label class="control-label col-sm-3"> Select Subject</label>
                        <div class="col-sm-9">
                            <select class="select2 form-control select2-multiple" id="test_subject_id" multiple="multiple" name="subject_id[]" data-placeholder="Choose ..." required>
                                <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                    <option value="<?php echo e($r->id); ?>"><?php echo e($r->subject_name); ?></option> 
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                
                   

                    <div class="form-group row">
                        <label class="col-md-3 col-form-label">Question Pattern</label>
                        <div class="col-md-9">
                            <select class="form-control" name="question_pattern" >
                                <option value="">Select Question Pattern</option>
                                <?php $__currentLoopData = $question_pattern; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                    <option value="<?php echo e($r->id); ?>"><?php echo e($r->question_pattern_name); ?></option> 
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>

                    

                    <div class="form-group row">
                        <label class="col-sm-3 col-form-label">Total Question</label>
                        <div class="col-sm-9">
                            <input type="text" class="form-control" name="total_question"  placeholder="Enter Total Question" required/>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label class="col-sm-3 col-form-label">Total Marks</label>
                        <div class="col-sm-9">
                            <input type="text" class="form-control" name="total_marks"  placeholder="Enter Total Marks" required/>
                        </div>
                    </div>

                    

                    <div class="form-group row">
                        <label class="col-sm-3 col-form-label">Test Duration</label>
                        <div class="col-sm-4">
                            <input type="number" class="form-control" name="hours"  placeholder="Enter hours" required/>
                        </div>
                        <div class="col-sm-4">
                            <input type="number" class="form-control" name="minute"  placeholder="Enter minute" required/>
                        </div>
                    </div>

                    

                    <div class="form-group row">
                        <label class="col-sm-3 col-form-label">Status</label>
                        <div class="col-sm-9">
                            <select class="form-control" name="status">                                    
                                <option value="1">Active</option>
                                <option value="0">De-Active</option>                                     
                            </select>
                        </div>
                    </div>
                    <div class="form-group text-center mt-5">
                        <div>
                            <button type="reset" class="btn btn-secondary waves-effect m-l-5">
                            Cancel
                            </button>
                            <button type="submit" class="btn btn-primary waves-effect waves-light">
                            Submit
                            </button>
                           
                        </div>

                        <div class="any_message mt-3">
                            <?php if($errors->any()): ?>
                                <div class="alert alert-danger">
                                    <ul>
                                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li><?php echo e($error); ?></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                        </button>
                                    </ul>
                                </div>
                            <?php endif; ?>
                            <?php if(session()->has('alert-danger')): ?>
                                <div class="alert alert-danger">
                                    <?php echo e(session()->get('alert-danger')); ?>

                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                            <?php endif; ?>
                                <?php if(session()->has('alert-success')): ?>
                                <div class="alert alert-success">
                                    <?php echo e(session()->get('alert-success')); ?>

                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<!-- end col -->


<?php /**PATH D:\xampp\htdocs\new_zlearn\resources\views/Admin/components/admin_add_test.blade.php ENDPATH**/ ?>