<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible"
      content="IE=edge">
<meta name="viewport"
      content="width=device-width, initial-scale=1, shrink-to-fit=no">
<title>Dashboard</title>

        <!-- Prevent the demo from appearing in search engines -->
        <meta name="robots"
        content="noindex">

  <link href="https://fonts.googleapis.com/css?family=Lato:400,700%7CRoboto:400,500%7CExo+2:600&display=swap"
        rel="stylesheet">

  <!-- Preloader -->
  
      <link href="<?php echo e(asset('Student/vendor/spinkit.css')); ?>" rel="stylesheet" type="text/css" />


  <!-- Perfect Scrollbar -->
  <link type="text/css"
        href="<?php echo e(asset('Student/vendor/perfect-scrollbar.css')); ?>"
        rel="stylesheet">

  <!-- Material Design Icons -->
  <link type="text/css"
        href="<?php echo e(asset('Student/css/material-icons.css')); ?>"
        rel="stylesheet">

  <!-- Font Awesome Icons -->
  <link type="text/css"
        href="<?php echo e(asset('Student/css/fontawesome.css')); ?>"
        rel="stylesheet">

  <!-- Preloader -->
  <link type="text/css"
        href="<?php echo e(asset('Student/css/preloader.css')); ?>"
        rel="stylesheet">

        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css"
        integrity="sha512-vKMx8UnXk60zUwyUnUPM3HbQo8QfmNx7+ltw8Pm5zLusl1XIfwcxo8DbWCqMGKaWeNxWA8yrx5v3SaVpMvR3CA=="
        crossorigin="anonymous" />

  <!-- App CSS -->
  <link type="text/css"
        href="<?php echo e(asset('Student/css/app.css')); ?>"
        rel="stylesheet">

        <!-- Custom  CSS -->
  <link type="text/css"
  href="<?php echo e(asset('Student/css/custom.css')); ?>"
  rel="stylesheet">


<?php /**PATH D:\xampp\htdocs\new_zlearn\resources\views/Students/Common/student_head.blade.php ENDPATH**/ ?>