<table>
    <thead>
    <tr>
        <th>Student Id </th>
        <th>Student First Name</th>
        <th>Student Last Name</th>
        <th>Mobile</th>
        <th>Email</th>
    </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $student; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($row->id); ?></td>   
            <td><?php echo e($row->name); ?></td>
            <td><?php echo e($row->l_name); ?></td>
            <td><?php echo e($row->phone); ?></td>
            <td><?php echo e($row->email); ?></td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table><?php /**PATH D:\xampp\htdocs\new_zlearn\resources\views/admin/components/admin_view_user_export.blade.php ENDPATH**/ ?>