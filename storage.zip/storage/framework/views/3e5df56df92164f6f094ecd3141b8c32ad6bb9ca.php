
<div class="col-12">
    <div class="card">
        <div class="card-body"> 
            <div class="col-12 text-right pb-2"> 
                <a href="<?php echo e(url('add-test-section')); ?>" class="btn btn-info">Add Test Section</a>
            </div>    
        <table id="datatable-buttons" class="table table-striped table-bordered dt-responsive nowrap text-center" style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                <thead>
                    <tr>
                        <th>No </th>
                        <th>Test Section</th>
                        <th>Status</th>                            
                        <th>Action</th>                    
                    </tr>
                </thead>

                <tbody>
                    <?php $i = 1; ?>
                    <?php $__currentLoopData = $test_section; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($i++); ?></td>
                        <td><?php echo e($row->test_section_name); ?></td>                            
                        <td><?php if($row->status == 1): ?> Active <?php else: ?> De-Active <?php endif; ?></td>
                        <td><a href="<?php echo e(url('edit-test-section/'.$row->id)); ?>" class="btn btn-info mr-2">Edit</a><a href="<?php echo e(url('delete-test-section/'.$row->id)); ?>" class="btn btn-danger">Delete</a></td>                                               
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   
                </tbody>
            </table>
        </div>
    </div>
</div>

<style>
    .dt-buttons
    {
        display:none!important;
    }
 </style>   
<!-- end col -->
<?php /**PATH D:\xampp\htdocs\new_zlearn\resources\views/Admin/components/view_test_section.blade.php ENDPATH**/ ?>