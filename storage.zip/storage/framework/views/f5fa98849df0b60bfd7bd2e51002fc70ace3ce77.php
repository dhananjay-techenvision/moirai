<!-- header begin -->
<header>

	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<!-- logo begin -->
				<div id="logo">
					<a href="index.html">
						<img class="logo" src="<?php echo e(asset('/website/images/logo-light.png')); ?>" alt="">
						<img class="logo-2" src="<?php echo e(asset('/website/images/logo-dark.png')); ?>" alt="">
					</a>
				</div>
				<!-- logo close -->

				<!-- small button begin -->
				<span id="menu-btn"></span>
				<!-- small button close -->

				<!-- mainmenu begin -->
				<nav>
					<ul id="mainmenu">
						<li><a href="<?php echo e(url('/')); ?>">Home<span></span></a>
							
						</li>
						<li><a href="#">Pages<span></span></a>
							
						</li>
						<li><a href="#">Services<span></span></a>
							
						</li>
						<li><a href="#">Gallery<span></span></a>
							
						</li>
						
						
						<li><a href="#">Contact<span></span></a>
							
						</li>

					<li><a href="<?php echo e(url('Web-login')); ?>">Login<span></span></a>
						</li>
					</ul>
				</nav>
				<!-- mainmenu close -->

		</div>
	</div>
</header>
<!-- header close --><?php /**PATH D:\xampp\htdocs\new_zlearn\resources\views/layouts/website_nav.blade.php ENDPATH**/ ?>