

<?php $__env->startSection('title'); ?> Dashboard <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <?php $__env->startComponent('common-components.breadcrumb'); ?>
         <?php $__env->slot('title'); ?> Dashboard   <?php $__env->endSlot(); ?>
         
     <?php if (isset($__componentOriginalca1ecd71c079b0986f63b19e32f1541d590c0929)): ?>
<?php $component = $__componentOriginalca1ecd71c079b0986f63b19e32f1541d590c0929; ?>
<?php unset($__componentOriginalca1ecd71c079b0986f63b19e32f1541d590c0929); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>

                    <div class="row">
                        <div class="col-xl-3">
                            
     
     
                        </div>

                        

                        
                    </div>
                    <!-- end row -->

                    
                    <!-- end row -->

                    
                    <!-- end row -->

                    
                    <!-- end row -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
        <!-- plugin js -->
        <script src="<?php echo e(URL::asset('libs/apexcharts/apexcharts.min.js')); ?>"></script>
        
        <!-- jquery.vectormap map -->
        <script src="<?php echo e(URL::asset('libs/jquery-vectormap/jquery-vectormap.min.js')); ?>"></script>
        
        <!-- Calendar init -->
        <script src="<?php echo e(URL::asset('js/pages/dashboard.init.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\new_zlearn\resources\views/index.blade.php ENDPATH**/ ?>