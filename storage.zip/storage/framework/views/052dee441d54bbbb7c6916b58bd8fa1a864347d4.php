<!DOCTYPE html>
<html lang="en"
      dir="ltr">

    <head>
      <?php echo $__env->make('Students.Common.student_head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </head>

    <body class="layout-app ">

        <div class="preloader">
            <div class="sk-chase">
                <div class="sk-chase-dot"></div>
                <div class="sk-chase-dot"></div>
                <div class="sk-chase-dot"></div>
                <div class="sk-chase-dot"></div>
                <div class="sk-chase-dot"></div>
                <div class="sk-chase-dot"></div>
            </div>
        
            <!-- More spinner examples at https://github.com/tobiasahlin/SpinKit/blob/master/examples.html -->
        </div>
        
        <!-- Drawer Layout -->
        
        <div class="mdk-drawer-layout js-mdk-drawer-layout"
             data-push
             data-responsive-width="992px">
            <div class="mdk-drawer-layout__content page-content">
        
                <!-- Header -->
        
                <!-- Navbar -->
        
                <?php echo $__env->make('Students.Common.student_navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        
                <!-- // END Navbar -->
        
                <!-- // END Header -->

                <div class="pt-32pt">
                    <div class="container page__container d-flex flex-column flex-md-row align-items-center text-center text-sm-left">
                        <div class="flex d-flex flex-column flex-sm-row align-items-center mb-24pt mb-md-0">

                            <div class="mb-24pt mb-sm-0 mr-sm-24pt">
                                <h2 class="mb-0">Dashboard</h2>

                                <ol class="breadcrumb p-0 m-0">
                                    <li class="breadcrumb-item"><a href="index.html">Home</a></li>

                                    <li class="breadcrumb-item active">
                                        &nbsp;<?php echo e($page_title); ?>

                                        

                                    </li>

                                </ol>

                            </div>
                        </div>

                        

                    </div>
                </div>

                <!-- BEFORE Page Content -->

                <!-- // END BEFORE Page Content -->

                <!-- Page Content -->

    <div class="container page__container bg-white mt-2">
        <div class="page-section ">
            <div class="row text-center h5">
                <div class="col-md-2 p-2 border">
                    <div class="col-12">Questions</div>
                    <div class="col-12 h4 p-2"><?= count($Q_total); ?></div>
                </div>
                <div class="col-md-2 p-2 border">
                    <div class="col-12">Completed</div>
                    <div class="col-12 h4 p-2"><?= count($Compl_total); ?></div>
                    
                </div>
                <div class="col-md-2 p-2 border">
                    <div class="col-12">Unanswered</div>
                    <div class="col-12 h4 p-2"><?= count($U_total);?></div>                    
                </div>
                <div class="col-md-2 p-2 border">
                    <div class="col-12">Correct</div>
                    <div class="col-12 h4 p-2"><?= count($C_total);?></div>                    
                </div>
                <div class="col-md-2 p-2 border">
                    <div class="col-12">Wrong</div>
                    <div class="col-12 h4 p-2"><?= count($W_total); ?></div>                    
                </div>
                <div class="col-md-2 p-2 border">
                    <div class="col-12"> Total Score</div>
                    <div class="col-12 h4 p-2"><?= count($C_total) * $Test_time->mark_per_question ;?></div>                   
                </div>

                <div class="col-12 mt-3">
                    <div class="alert alert-success h3" role="alert">
                       <?php echo e($Test_time->test_name); ?> Submited !!!!
                    </div>
                </div>
                    <?php $j = 1; ?>
                   <?php $__currentLoopData = $W_total; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php    
                            $Question = DB::table('questions')->where('id',$item->question_id)->first();
                    ?>
                        <div class="col-md-12 row">
                            <?php if($Question->question): ?>
                                <label class="h5"><span class="h3 mr-2">Q. <?php echo e($j++); ?></span> <?php echo e($Question->question); ?></label>
                            <?php endif; ?>
                        </div>
                        <div class="col-md-12 row">
                            <?php if($Question->question_image): ?>
                                <img src="<?php echo e(url($Question->question_image)); ?>" class="img-thumbnail">
                            <?php endif; ?>
                        </div>
                        <?php  $Q_option = DB::table('answers')->where('question_id',$Question->id)->get(); 
                            $i=1;
                        foreach ($Q_option as  $value) 
                        { ?>
                        <?php if($Question->correct_answer == $i): ?>
                        <div class="col-md-6 h5 row">                            
                            
                                <label>Correct Answer :- <span class="text-info"><?php echo e($value->answer); ?></span></label>
                        </div>
                       <?php endif; ?>
                    <?php $i++; }
                    // dd($Question);
                             ?>

                    <div class="col-md-12 bg-info px-3 py-2  mb-3">        
                        <p class="text-left font-weight-bold text-dark">Explanation :- </p>
                        <p class="h5 text-left"><?php echo e($Question->explanation); ?></p>
                    </div>      

                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
            </div>    


        </div>
    </div>

    <!-- // END Page Content -->


                <!-- Footer -->

                <!-- <?php echo $__env->make('Students.Common.student_footertext', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> -->

                <!-- // END Footer -->

            </div>

            <!-- // END drawer-layout__content -->

            <!-- Drawer left sidebar start -->

            <?php echo $__env->make('Students.Common.student_sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <!-- // END Drawer sidebar ends -->

        </div>

        <!-- // END Drawer Layout -->

        <?php echo $__env->make('Students.Common.student_footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        
        <script>
            $(document).ready(function()
            {
                localStorage.clear();
            });
        </script>
    </body>

</html><?php /**PATH D:\xampp\htdocs\new_zlearn\resources\views/Students/Webviews/Test_result.blade.php ENDPATH**/ ?>