
<div class="col-12">
    <div class="card">
        <div class="card-body"> 
            <div class="col-12 text-right pb-2"> 
                
            </div>    
        <table id="datatable-buttons" class="table table-striped table-bordered dt-responsive nowrap text-center" style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                <thead>
                    <tr>
                        <th>No </th>
                        <th>Program Name</th>
                        <th>Status</th>                            
                        
                    
                    </tr>
                </thead>

                <tbody>
                    <?php $i = 1; ?>
                    <?php $__currentLoopData = $program_name; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($i++); ?></td>
                        <td><?php echo e($row->program_name); ?></td>                            
                        <td><?php if($row->status == 1): ?> Active <?php else: ?> De-Active <?php endif; ?></td>
                        
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   
                </tbody>
            </table>
        </div>
    </div>
</div>

<style>
    .dt-buttons
    {
        display:none!important;
    }
 </style>   
<!-- end col -->
<?php /**PATH D:\xampp\htdocs\new_zlearn\resources\views/Admin/components/view_program_name.blade.php ENDPATH**/ ?>