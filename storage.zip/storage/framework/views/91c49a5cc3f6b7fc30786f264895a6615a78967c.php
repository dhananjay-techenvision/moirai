
    <div class="col-12">
        <div class="card">
            <div class="card-body">

                
                

                <table id="datatable-buttons" class="table table-striped table-bordered dt-responsive nowrap" style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                    <thead>
                        <tr>
                            <th>Username </th>
                            <th>Email</th>
                            <th>Mobile No.</th>
                            <th>Status</th>
                            <th>Action</th>
                        
                        </tr>
                    </thead>

                    <tbody>
                        <tr>
                            <td>Admin</td>
                            <td>Admin@gmail.com</td>
                            <td>9876543210</td>
                            <td>active</td>
                            <td> <i class="fas fa-archive"></i> </td>                                               
                        </tr>
                       
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <!-- end col -->
<?php /**PATH D:\xampp\htdocs\new_zlearn\resources\views/Admin/components/admin_view_user.blade.php ENDPATH**/ ?>