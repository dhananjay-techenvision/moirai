
<div class="col-12">
    <div class="card">
        <div class="card-body">

            
            
            <div class="col-md-8 m-auto">                                       
                <form class="" action="<?php echo e(url('submit-blogs')); ?>" method="POST" enctype="multipart/form-data">                        
                <?php echo csrf_field(); ?> 
                    <div class="form-group row">
                        <label class="col-sm-3 col-form-label">Title</label>
                        <div class="col-sm-9">
                            <input type="text" class="form-control" name="blog_title"  placeholder="Enter Title" required/>
                        </div>
                    </div>   
                    <div class="form-group row">
                        <label class="col-sm-3 col-form-label">Blog Date</label>
                        <div class="col-sm-9">
                            <input type="date" class="form-control" name="blog_date"/>
                        </div>
                    </div>  
                    
                    <div class="form-group row">
                        <label class="col-sm-3 col-form-label">Blog Content</label>
                        <div class="col-sm-9">
                            <div class="form-group">                            
                                <div>
                                    <textarea  class="form-control" rows="3" name="blog_content" placeholder="Enter Content"></textarea>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label class="col-md-3 col-form-label">Image </label>
                        <div class="col-md-9">
                            <input type="file" name="blog_image">
                        </div>
                    </div>

                    <div class="form-group row">
                        <label class="col-sm-3 col-form-label">Status</label>
                        <div class="col-sm-9">
                            <select class="form-control" name="status">                                    
                                <option value="1">Active</option>
                                <option value="0">De-Active</option>                                     
                            </select>
                        </div>
                    </div>
                    <div class="form-group text-center mt-5">
                        <div>
                            <button type="reset" class="btn btn-secondary waves-effect m-l-5">
                            Cancel
                            </button>
                            <button type="submit" class="btn btn-primary waves-effect waves-light">
                            Submit
                            </button>
                           
                        </div>

                        <div class="any_message mt-3">
                            <?php if($errors->any()): ?>
                                <div class="alert alert-danger">
                                    <ul>
                                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li><?php echo e($error); ?></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                        </button>
                                    </ul>
                                </div>
                            <?php endif; ?>
                            <?php if(session()->has('alert-danger')): ?>
                                <div class="alert alert-danger">
                                    <?php echo e(session()->get('alert-danger')); ?>

                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                            <?php endif; ?>
                                <?php if(session()->has('alert-success')): ?>
                                <div class="alert alert-success">
                                    <?php echo e(session()->get('alert-success')); ?>

                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<!-- end col -->


<?php /**PATH D:\xampp\htdocs\final_moirah\resources\views/Admin/components/add_blogs.blade.php ENDPATH**/ ?>