<!DOCTYPE html>
<html lang="en"
      dir="ltr">

    <head>
      <?php echo $__env->make('Students.Common.student_head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </head>

    <body class="layout-app ">

        <div class="preloader">
            <div class="sk-chase">
                <div class="sk-chase-dot"></div>
                <div class="sk-chase-dot"></div>
                <div class="sk-chase-dot"></div>
                <div class="sk-chase-dot"></div>
                <div class="sk-chase-dot"></div>
                <div class="sk-chase-dot"></div>
            </div>
        
            <!-- More spinner examples at https://github.com/tobiasahlin/SpinKit/blob/master/examples.html -->
        </div>
        
        <!-- Drawer Layout -->
        
        <div class="mdk-drawer-layout js-mdk-drawer-layout"
             data-push
             data-responsive-width="992px">
            <div class="mdk-drawer-layout__content page-content">
        
                <!-- Header -->
        
                <!-- Navbar -->
        
                <?php echo $__env->make('Students.Common.student_navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        
                <!-- // END Navbar -->
        
                <!-- // END Header -->

                <div class="pt-35pt bg-primary">
                    <div class="container page__container d-flex flex-column flex-md-row align-items-center text-center text-sm-left">
                        

                        
                        <div class="hero py-64pt text-center text-sm-left">
                            <div class="container page__container">
                                                      
                                   <table class="table table-bordered text-white table-sm text-center">
                                       <tr>
                                          <td>Test Name</td>
                                          <td class="bg-warning">Demo</td>
                                          <td>Total Questions</td>
                                          <td class="bg-warning">10</td>
                                           <td>Total Time</td>
                                          <td class="bg-warning">1:30</td>
                                       </tr>
                                   </table>
                                    <table class="table table-bordered text-white table-sm text-center">
                                       <tr>
                                          <td class="tb_col">Section Name</td>
                                          <td class="">No. of Questions</td>
                                          <td class="tb_col">Time limit</td>
                                          <td class="">Marks per Question</td>
                                           <td class="tb_col">Negative Marking</td>                                  
                                       </tr>                                        
                                        <tr>
                                          <td class="tb_col">Section Name 1</td>
                                          <td class="">25</td>
                                          <td class="tb_col">00:25(h:m)</td>
                                          <td class="">1</td>
                                           <td class="tb_col">1/3</td>                                  
                                       </tr>
                                        <tr>
                                          <td class="tb_col">Section Name 2</td>
                                          <td class="">25</td>
                                          <td class="tb_col">00:25(h:m)</td>
                                          <td class="">1</td>
                                           <td class="tb_col">1/3</td>                                  
                                       </tr>
                                        <tr>
                                          <td class="tb_col">Section Name 3</td>
                                          <td class="">25</td>
                                          <td class="tb_col">00:25(h:m)</td>
                                          <td class="">1</td>
                                           <td class="tb_col">1/3</td>                                  
                                       </tr>
                                        <tr>
                                          <td class="tb_col">Section Name 4</td>
                                          <td class="">25</td>
                                          <td class="tb_col">00:25(h:m)</td>
                                          <td class="">1</td>
                                           <td class="tb_col">1/3</td>                                  
                                       </tr>
                                   </table>
                                   <div class="row text-center">
                                       <div class="col-md-6">
                                           <p class="text-white h4">General Directions:</p>
                                           
                                           
                                           <ul class="text-left text-white pr-2" style="font-size: 14px;">
                                                <li> This test is designed to check your competency in all the sections.
                                                </li>
                                                <li>You are advised to conduct the test with complete seriousness and environment simulated to match the actual test conditions.</li> 
                                               <li>You can quit the test at any time by pressing Quit Test button (Available in the Review Screen) & take it later. While quitting the test you will get the option to start the test afresh or resume it from saved attempt.</li>
                                               <li>Press the Quit Test button once you have finished taking the test. Once submitted you cannot retake this test.</li>
                                               <li>On completion of the test, you can view the Score Card.</li>    
                                           </ul>
                                       </div>
                                       <div class="col-md-6">
                                            <p class="text-white h4">General Instructions:</p>
                                           
                                           
                                           <ul class="text-left text-white pr-2" style="font-size: 14px;">
                                                <li> Total duration of examination is 100 minutes. 
                                                </li>
                                                <li> Your clock will be set at the server. The countdown timer at the top right corner of screen will display the remaining time available for you to complete the examination. When the timer reaches zero, the examination will end by itself. You need not terminate the examination or submit your paper.</li> 
                                               <li>You are not allowed to use any calculator and any other computing machine.</li>
                                               <li>Click on the question number in the Question Palette to go to that question directly.</li>
                                               <li> Select an answer for a multiple choice type question by clicking on the bubble placed before the 4 choices in the form of radio buttons (o).</li>
                                               <li> Click on Save & Next to save your answer for the current question and then go to the next question. </li>    
                                           </ul>
                                       </div>
                                       <div class="col-12 text-center">
                                         <a href="<?php echo e(url('studentdashboard')); ?>" class="btn btn-outline-secondary btn-lg">Cancel</a>
                                        <a href="<?php echo e(url('Start-Test-Demo')); ?>/<?php echo e($test_id); ?>" class="btn btn-outline-warning btn-lg">Start >></a>
                                           
                                       </div>
                                   </div>
                            </div>
                        </div>

                    </div>
                </div>

                <!-- BEFORE Page Content -->

                <!-- // END BEFORE Page Content -->

                <!-- Page Content -->

    <div class="container page__container">
        <div class="page-section">
        
        

        </div>
    </div>

    <!-- // END Page Content -->


                <!-- Footer -->

                <!-- <?php echo $__env->make('Students.Common.student_footertext', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> -->

                <!-- // END Footer -->

            </div>

            <!-- // END drawer-layout__content -->

            <!-- Drawer left sidebar start -->

            <?php echo $__env->make('Students.Common.student_sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <!-- // END Drawer sidebar ends -->

        </div>

        <!-- // END Drawer Layout -->

        <?php echo $__env->make('Students.Common.student_footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <style>
            .tb_col
            {
                background-color: #e4a93c!important;
            }
        </style>
        <script>
            $(document).ready(function()
            {
                $('.test_done').click(function()
                {
                    alert("This Test Already Completed !!!");
                });
            });
        </script>    
    </body>

</html><?php /**PATH D:\xampp\htdocs\new_zlearn\resources\views/Students/Webviews/Test_Instraction.blade.php ENDPATH**/ ?>