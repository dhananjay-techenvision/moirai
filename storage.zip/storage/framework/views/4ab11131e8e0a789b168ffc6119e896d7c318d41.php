
<div class="col-12">
    <div class="card">
        <div class="card-body"> 
            <div class="col-12 text-right pb-2"> 
                <a href="<?php echo e(url('add-category')); ?>" class="btn btn-info">Add Categories</a>
            </div>    
        <table id="datatable-buttons" class="table table-striped table-bordered dt-responsive nowrap text-center" style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                <thead>
                    <tr>
                        <th>No </th>
                        <th>Categories Name</th>
                        <th>Status</th>                            
                        <th>Action</th>
                    </tr>
                </thead>

                <tbody>
                    <?php $i = 1; ?>
                    <?php $__currentLoopData = $Categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($i++); ?></td>
                        <td><?php echo e($row->category_name); ?></td>                            
                        <td><?php if($row->status == 1): ?> Active <?php else: ?> De-Active <?php endif; ?></td>
                        <?php
                        $deactive = 0;
                        $active = 1;
                        ?>
                        <td>
                            <a href="<?php echo e(url('edit-category/'.$row->id)); ?>" class="btn btn-info mr-2">Edit</a>
                             <?php if($row->status == 1): ?> <a href="<?php echo e(url('update-category/'.$row->id.'/'.$deactive)); ?>" class="btn btn-danger">Deactive</a><?php else: ?> <a href="<?php echo e(url('update-category/'.$row->id.'/'.$active)); ?>" class="btn btn-info">Active</a><?php endif; ?> </td>                                               
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   
                </tbody>
            </table>
        </div>
    </div>
</div>

<style>
    .dt-buttons
    {
        display:none!important;
    }
 </style>   
<!-- end col -->
<?php /**PATH D:\xampp\htdocs\final_moirah\resources\views/Admin/components/categories_list.blade.php ENDPATH**/ ?>