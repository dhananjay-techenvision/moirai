<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible"
          content="IE=edge">
    <meta name="viewport"
          content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Student Dashboard</title>
          <?php echo $__env->make('layouts.student_head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          <?php echo toastr_css(); ?>
</head>
    
    <?php echo $__env->yieldContent('body'); ?>
    <?php echo $__env->make('layouts.student_footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo toastr_js(); ?>
    <?php echo app('toastr')->render(); ?>

</html><?php /**PATH D:\xampp\htdocs\new_zlearn\resources\views/layouts/student.blade.php ENDPATH**/ ?>