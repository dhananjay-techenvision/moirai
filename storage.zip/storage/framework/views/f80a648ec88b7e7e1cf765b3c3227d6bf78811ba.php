<table>
    <thead>
    <tr>
        <th>Student Id </th>
        <th>Student First Name</th>
        <th>Student Last Name</th>
        <th>Mobile</th>
        <th>Email</th>
        <th>Gender</th>
        <th>DOB</th>
        <th>Blood Group</th>
        <th>Address</th>
        <th>State</th>        
        <th>College</th>
        <th>Course</th>
        <th>Branch</th>
        <th>Semester</th>
        <th>Roll No</th>
        <th>Education</th>
    </tr>
    </thead>
    <tbody>
        <?php  $i = 1; ?>
    <?php $__currentLoopData = $student; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($i++); ?></td>   
            <td><?php echo e($row->name); ?></td>
            <td><?php echo e($row->l_name); ?></td>
            <td><?php echo e($row->phone); ?></td>
            <td><?php echo e($row->email); ?></td>
            <td><?php echo e($row->gender); ?></td>
            <td><?php echo e($row->dob); ?></td>
            <td><?php echo e($row->blood_group); ?></td>
            <td><?php echo e($row->address); ?></td>
            <td><?php echo e($row->state); ?></td>
            <td><?php echo e($row->college_name); ?></td>
            <td><?php echo e($row->compus); ?></td>
            <td><?php echo e($row->branch_name); ?></td>
            <td><?php echo e($row->semister_name); ?></td>
            <td><?php echo e($row->roll_no); ?></td>
            <td><?php echo e($row->education); ?></td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table><?php /**PATH D:\xampp\htdocs\new_zlearn\resources\views/Admin/components/admin_view_user_export.blade.php ENDPATH**/ ?>