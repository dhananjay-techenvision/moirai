
<div class="col-12">
    <div class="card">
        <div class="card-body">

            
            
            <div class="col-md-8 m-auto">                                       
                <form class="" action="<?php echo e(url('submit-question')); ?>" method="POST" enctype="multipart/form-data">                        
                <?php echo csrf_field(); ?>                   
                    
                    <input type="hidden" name="question_id" value="<?php echo e($question->id); ?>">
                    <div class="form-group row">
                        <label class="col-sm-3 col-form-label">Subject</label>
                        <div class="col-sm-9">
                            <select class="form-control" name="subject_id" required>
                                <option value="">Select Subject</option>
                                <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                                     
                                    <option value="<?php echo e($r->id); ?>" <?php if($r->id == $question->subject_id): ?>selected <?php endif; ?>><?php echo e($r->subject_name); ?></option> 
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>   
                            </select>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label class="col-sm-3 col-form-label"> Old Chapter</label>
                        <div class="col-sm-9">
                            <input type="text" class="form-control" name="old_chapter" value="<?php echo e($question->chapter_name); ?>" readonly/>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label class="col-sm-3 col-form-label">Chapter</label>
                        <div class="col-sm-9">
                            <select class="form-control" name="chapter_id">
                                 <option value="">Select Chapter</option>
                              
                            </select>
                        </div>
                    </div>
                    
                    <div class="form-group row">
                        <label class="col-sm-3 col-form-label"> Question Type </label>                
                        <div class="col-md-9">
                            <div class="row">
                                
                                <div class="form-check mb-2 col-6">
                                    <input class="form-check-input" type="radio"  name="question_type" id="exampleRadios1" value="1"  <?php echo ($question->question_type == '1') ?  "checked" : "" ;  ?> >
                                    <label class="form-check-label" for="exampleRadios1">
                                       Image
                                    </label>
                                </div>
                                <div class="form-check col-6">
                                    <input class="form-check-input" type="radio"  name="question_type" id="exampleRadios2" value="0" <?php echo ($question->question_type == '0') ?  "checked" : "" ;  ?>>
                                    <label class="form-check-label" for="exampleRadios2">
                                        Text
                                    </label>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label class="col-sm-3 col-form-label">Question </label>
                        <div class="col-sm-9">
                            <div class="form-group">                            
                                <div>
                                    <textarea  class="form-control" rows="3" name="question" placeholder="Enter Question"><?php echo e($question->question); ?> </textarea>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label class="col-md-3 col-form-label">Question </label>
                        <div class="col-md-9">
                            <input type="file" class="custom-file-input" id="customFile" name="question_image_new">
                            <label class="custom-file-label" for="customFile">Choose file</label>
                        </div>
                    </div>

                    <div class="form-group row">
                    <?php if($question->question_image): ?>
                    <label class="col-md-2 col-form-label">Question </label>
                    <div class="col-md-8">
                        <img class="document_img" src="<?php echo e(asset($question->question_image)); ?>" alt="" width="100" height="100">
                    </div>
                    <div class="col-md-2">
                        <a href="<?php echo e(url('delete-question-image')); ?>/<?php echo e($question->id); ?>" class="btn btn-accent float-right" title="Delete"><i class="fa fa-trash " style="color: red;" aria-hidden="true"></i></a>
                    </div>
                    <?php endif; ?>
                </div>
                
                    <div class="form-group row">
                        <label class="col-md-3 col-form-label">Choice Count</label>
                        <div class="col-md-9">
                            <select class="form-control" name="choice_count"  disabled="true">
                                <option>Select Choice</option>
                                <option value="2" <?php if($question->choice_count == "2"): ?>selected <?php endif; ?>>2</option>
                                <option value="3" <?php if($question->choice_count == "3"): ?>selected <?php endif; ?>>3</option>
                                <option value="4" <?php if($question->choice_count == "4"): ?>selected <?php endif; ?>>4</option>
                                <option value="5" <?php if($question->choice_count == "5"): ?>selected <?php endif; ?>>5</option>                                                               
                            </select>
                        </div>
                    </div>

                   
                    <div class="form-group row">
                        <label class="col-sm-3 col-form-label">Explanation </label>
                        <div class="col-sm-9">
                            <div class="form-group">                            
                                <div>
                                    <textarea  class="form-control" rows="3" name="explanation" placeholder="Enter Explanation"><?php echo e($question->explanation); ?> </textarea>
                                </div>
                            </div>
                        </div>
                    </div>

                    
                    <div class="form-group row">
                        <label class="col-sm-3 col-form-label">Level</label>
                        <div class="col-sm-9">
                            <select class="form-control" name="question_level" required>
                                <option value="">Select Level</option>
                                <?php $__currentLoopData = $question_level; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                    <option value="<?php echo e($r->id); ?>" <?php if($r->id == $question->question_level): ?>selected <?php endif; ?>><?php echo e($r->question_level_name); ?></option> 
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label class="col-sm-3 col-form-label">Section</label>
                        <div class="col-sm-9">
                            <select class="form-control" name="test_section" required>
                                <option value="">Select Section</option>
                                <?php $__currentLoopData = $test_section; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                    <option value="<?php echo e($r->id); ?>" <?php if($r->id == $question->test_section): ?>selected <?php endif; ?>><?php echo e($r->test_section_name); ?></option> 
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>

                    

                    <div class="form-group row">
                        <label class="col-sm-3 col-form-label">Status</label>
                        <div class="col-sm-9">
                            <select class="form-control" name="status">                                    
                                <option value="1">Active</option>
                                <option value="0">De-Active</option>                                     
                            </select>
                        </div>
                    </div>
                    <div class="form-group text-center mt-5">
                        <div>
                            <button type="reset" class="btn btn-secondary waves-effect m-l-5">
                            Cancel
                            </button>
                            <button type="submit" class="btn btn-primary waves-effect waves-light">
                            Submit
                            </button>
                           
                        </div>

                        <div class="any_message mt-3">
                            <?php if($errors->any()): ?>
                                <div class="alert alert-danger">
                                    <ul>
                                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li><?php echo e($error); ?></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                        </button>
                                    </ul>
                                </div>
                            <?php endif; ?>
                            <?php if(session()->has('alert-danger')): ?>
                                <div class="alert alert-danger">
                                    <?php echo e(session()->get('alert-danger')); ?>

                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                            <?php endif; ?>
                                <?php if(session()->has('alert-success')): ?>
                                <div class="alert alert-success">
                                    <?php echo e(session()->get('alert-success')); ?>

                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<!-- end col -->



<?php /**PATH D:\xampp\htdocs\new_zlearn\resources\views/Admin/components/question/admin_edit_question.blade.php ENDPATH**/ ?>