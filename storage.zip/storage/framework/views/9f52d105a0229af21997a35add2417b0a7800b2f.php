<!DOCTYPE html>
<html lang="en"
    dir="ltr">
    <head>
        <?php echo $__env->make('Students.Common.student_head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </head>
    <body class="layout-app ">
        <div class="preloader">
            <div class="sk-chase">
                <div class="sk-chase-dot"></div>
                <div class="sk-chase-dot"></div>
                <div class="sk-chase-dot"></div>
                <div class="sk-chase-dot"></div>
                <div class="sk-chase-dot"></div>
                <div class="sk-chase-dot"></div>
            </div>
            
            <!-- More spinner examples at https://github.com/tobiasahlin/SpinKit/blob/master/examples.html -->
        </div>
        
        <!-- Drawer Layout -->
        
        <div class="mdk-drawer-layout js-mdk-drawer-layout"
            data-push
            data-responsive-width="992px">
            <div class="mdk-drawer-layout__content page-content">
                
                <!-- Header -->
                
                <!-- Navbar -->
                
                <?php echo $__env->make('Students.Common.student_navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                
                <!-- // END Navbar -->
                
                <!-- // END Header -->
                <div class="pt-32pt">
                    <div class="container page__container d-flex flex-column flex-md-row align-items-center text-center text-sm-left">
                        <div class="flex d-flex flex-column flex-sm-row align-items-center mb-24pt mb-md-0">
                            <div class="mb-24pt mb-sm-0 mr-sm-24pt">
                                <h2 class="mb-0">RESUME</h2>
                                <ol class="breadcrumb p-0 m-0">
                                    <li class="breadcrumb-item"><a href="JavaScript:Void(0);">Student</a></li>
                                    <li class="breadcrumb-item active">
                                        <!-- ACADEMIC Details -->
                                        <?php echo e($page_title); ?>

                                    </li>
                                </ol>
                            </div>
                        </div>
                        <!-- <div class="row"
                            role="tablist">
                            <div class="col-auto">
                                <a href="student-my-courses.html"
                                class="btn btn-outline-secondary">My Courses</a>
                            </div>
                        </div> -->
                    </div>
                </div>
                <!-- BEFORE Page Content -->
                <!-- // END BEFORE Page Content -->
                <!-- Page Content -->
                <div class="container page__container">
                    <div class="page-section">
                        <!-- =================================-->
                        <div class="any_message row col-12">
                            <?php if($errors->any()): ?>
                            <div class="alert alert-danger col-12">
                                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                                </button>
                                <ul>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                            <?php endif; ?>
                            <?php if(session()->has('alert-danger')): ?>
                            <div class="alert alert-danger col-12">
                                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                                </button>
                                <?php echo e(session()->get('alert-danger')); ?>

                            </div>
                            <?php endif; ?>
                            <?php if(session('success')): ?>
                            <div class="alert alert-success col-12">
                                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                                </button>
                                <?php echo e(session('success')); ?>

                            </div>
                            <?php endif; ?>
                        </div>
                        <!-- =================================== -->
                        <form class="form-group col-md-10 m-auto" action="<?php echo e(url('Academics-Info')); ?>" method="POST" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <!-- <div class="form-group row ">
                                <label class="form-label col-md-3 p-2">NAME:</label>
                                <input type="text" class="form-control col-md-9"
                                placeholder="Enter Your Name">
                            </div> -->
                            <div class="form-row">
                                <div class="col-12 col-md-6 mb-3">
                                    <label class="form-label" for="">SSLC PERCENTAGE(%)</label>
                                    <input type="text" class="form-control" name="sslc_per" id="" value="<?php if($Academics): ?><?php echo e($Academics->sslc_perce); ?><?php endif; ?>" placeholder="Enter Your SSLC Percentage" required="">
                                </div>
                                <div class="col-12 col-md-6 mb-3">
                                    <label class="form-label" for="">YEAR OF PASSING</label>
                                    <input type="text" class="form-control" id="" placeholder="Enter Year Of Passing (YYYY)" value="<?php if($Academics): ?><?php echo e($Academics->sslc_year); ?><?php endif; ?>" name="year_sslc" required="">
                                </div>
                            </div>
                            <div class="form-row">
                                <div class="col-12 col-md-6 mb-3">
                                    <label class="form-label" for="">PUC / 12th PERCENTAGE(%)</label>
                                    <input type="text" class="form-control" name="puc_per" id="" value="<?php if($Academics): ?><?php echo e($Academics->puc_perce); ?><?php endif; ?>" placeholder="Enter PUC / 12th Percentage" required="">
                                </div>
                                <div class="col-12 col-md-6 mb-3">
                                    <label class="form-label" for="">YEAR OF PASSING</label>
                                    <input type="text" class="form-control" id="" placeholder="Enter Year Of Passing (YYYY)" value="<?php if($Academics): ?><?php echo e($Academics->puc_year); ?><?php endif; ?>" name="year_puc" required="">
                                </div>
                            </div>
                            <div class="form-row">
                                <div class="col-12 col-md-6 mb-3">
                                    <label class="form-label" for="">DIPLOMA PERCENTAGE(%)</label>
                                    <input type="text" class="form-control" name="diploma_per" id="" value="<?php if($Academics): ?><?php echo e($Academics->diploma_perce); ?><?php endif; ?>" placeholder="Enter Diploma Percentage">
                                </div>
                                <div class="col-12 col-md-6 mb-3">
                                    <label class="form-label" for="">YEAR OF PASSING</label>
                                    <input type="text" class="form-control" id="" placeholder="EnterYear Of Passing" value="<?php if($Academics): ?><?php echo e($Academics->diploma_year); ?><?php endif; ?>" name="year_diploma" >
                                </div>
                            </div>
                            <div class="form-row">
                                <div class="col-12 col-md-6 mb-3">
                                    <label class="form-label" for="">GRADUATION</label>
                                   <select id="" name="ddl_graduation" class="form-control custom-select">
                                    <option value="" selected>Select Semester </option>
                                    <?php $__currentLoopData = $graduation_sem; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($list->sem_id); ?>" <?php if($UserDetails->semister == $list->sem_id): ?>selected <?php endif; ?>><?php echo e($list->sem_name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                                     
                                </select>
                                </div>
                                <div class="col-12 col-md-6 mb-3">
                                    <label class="form-label" for="">GRADUATION</label>
                                    <input type="text" class="form-control" id="" placeholder="Enter Other Graduation" value="<?php if($Academics): ?><?php echo e($Academics->other_graduation); ?><?php endif; ?>" name="write_graduation">
                                </div>
                            </div>
                            
                            <div class="form-row">
                                <div class="col-12 col-md-6 mb-3">
                                    <label class="form-label" for="">PG</label>
                                   <select id="" name="ddl_pg" class="form-control custom-select">
                                    <option value="" >Select Semester </option>
                                    <option value="1" <?php if($Academics): ?> <?php if($Academics->ddl_pg == "1"): ?>selected <?php endif; ?> <?php endif; ?>>1st Semester </option>
                                    <option value="2" <?php if($Academics): ?> <?php if($Academics->ddl_pg == "2"): ?>selected <?php endif; ?> <?php endif; ?>>2nd Semester </option>
                                    <option value="3" <?php if($Academics): ?> <?php if($Academics->ddl_pg == "3"): ?>selected <?php endif; ?> <?php endif; ?>>3rd Semester </option>
                                    <option value="4" <?php if($Academics): ?> <?php if($Academics->ddl_pg == "4"): ?>selected <?php endif; ?> <?php endif; ?>>4th Semester </option>
                                </select>
                                </div>
                                <div class="col-12 col-md-6 mb-3">
                                    <label class="form-label" for="">PG (Other)</label>
                                    <input type="text" class="form-control" id="" placeholder="Enter Other PG" value="<?php if($Academics): ?><?php echo e($Academics->other_pg); ?><?php endif; ?>" name="write_pg">
                                </div>
                            </div>
                            <div class="form-row">
                                <div class="col-12 col-md-6 mb-3">
                                    <label class="form-label" for="">TOTAL CGPA (AVG TOTAL)</label>
                                    <input type="text" class="form-control" name="avg_cgpa" id="" value="<?php if($Academics): ?><?php echo e($Academics->avg_cgpa); ?><?php endif; ?>" placeholder="Enter Total CGPA " >
                                </div>
                                <div class="col-12 col-md-6 mb-3">
                                    <label class="form-label" for="">YEAR OF GRADUATED <small>(FUTURE DATE (YYYY))</small></label>
                                    <input type="text" class="form-control" id="year_graduated1" placeholder="Enter Year Of Graduated (YYYY)" value="<?php if($Academics): ?><?php echo e($Academics->year_graduation); ?><?php endif; ?>" name="year_graduated">
                                </div>
                            </div>
                            <div class="form-row">
                                <div class="col-12 col-md-6 mb-3">
                                    <label class="form-label" for="">CURRENT BACK LOGS</label>
                                    <input type="number" class="form-control" name="current_backLog" min="0" id="" value="<?php if($Academics): ?><?php echo e($Academics->curr_backlog); ?><?php endif; ?>" placeholder="Enter Current Back Logs" >
                                </div>
                                <div class="col-12 col-md-6 mb-3">
                                    <label class="form-label" for="">NUMBER OF YEAR BACKS <small>(IF ANY)</small></label>
                                    <input type="text" class="form-control" id="" placeholder="Enter Number of Year Backs" value="<?php if($Academics): ?><?php echo e($Academics->num_year_backlog); ?><?php endif; ?>" name="no_yer_backs" >
                                </div>
                            </div>
                            <div class="form-row">
                                <div class="col-12 col-md-6 mb-3">
                                    <label class="form-label" for="">ANY GAPS IN THE ACADEMICS</label>
                                    <div class="custom-control custom-radio col-md-9 col-8 p-2">
                                        <span class="mr-3">
                                            <input type="radio" id="" name="acd_gaps" value="1" class="gaps" <?php if($Academics): ?> <?php if($Academics->gap == "1"): ?>checked <?php endif; ?> <?php endif; ?>>
                                            <label for="Yes" class="pl-1">Yes</label>
                                        </span>
                                        <span class="ml-3">
                                            <input type="radio" class="gaps" id="" name="acd_gaps" value="0"  <?php if($Academics): ?> <?php if($Academics->gap == "0"): ?>checked <?php endif; ?> <?php endif; ?>>
                                            <label for="No" class="pl-1">No</label>
                                        </span>
                                    </div>
                                </div>
                                <div class="col-12 col-md-6 mb-3">
                                    <label class="form-label" for="">Explain </label>
                                    <textarea class="form-control gap_explain" name="explain_gaps" placeholder="If Any Gaps In The Academics Then Explain" maxlength="300" readonly=""><?php if($Academics): ?><?php echo e($Academics->gap_explan); ?><?php endif; ?></textarea>
                                </div>
                            </div> 
                            <div class="form-group row">
                                <div class="col-10 m-auto text-right pt-3">
                                    
                                    <a href="<?php echo e(url('resume-page-one')); ?>" class="btn btn-secondary mr-2" >Back</a>
                                    <button name="submit" class="btn btn-primary">Save</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
                <!-- // END Page Content -->
                <!-- Footer -->
                <!-- <?php echo $__env->make('Students.Common.student_footertext', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> -->
                <!-- // END Footer -->
            </div>
            <!-- // END drawer-layout__content -->
            <!-- Drawer left sidebar start -->
            <?php echo $__env->make('Students.Common.student_sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- // END Drawer sidebar ends -->
        </div>
        <!-- // END Drawer Layout -->
        <?php echo $__env->make('Students.Common.student_footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        
         <link href = "https://code.jquery.com/ui/1.10.4/themes/ui-lightness/jquery-ui.css"
         rel = "stylesheet">
        
        <script src = "https://code.jquery.com/ui/1.10.4/jquery-ui.js"></script>
         <?php echo toastr_js(); ?>
        <?php echo app('toastr')->render(); ?>
        <script>
            $(document).ready(function()
            {
                $('#year_graduated').datepicker({
                    minDate: 1,
                    dateFormat: 'yy-mm-dd'
                });

              $('.gaps').click(function()
              {
                if($(this).val() == 1)
                {
                   $('.gap_explain').removeAttr('readonly');
                   $('.gap_explain').attr('required',true); 
                }
                else
                {                    
                    $('.gap_explain').removeAttr('required');
                    $('.gap_explain').attr('readonly',true);
                }
              });  
            });
        </script>
    </body>
</html><?php /**PATH D:\xampp\htdocs\new_zlearn\resources\views/Students/Webviews/student_add_academics.blade.php ENDPATH**/ ?>