
<div class="col-12">
    <div class="card">
        <div class="card-body"> 
            <div class="col-12 text-left pb-2"> 
                <h4 class="test-capitalize"> Test Name : <?php echo e($tests->test_name); ?>  </a>
            </div>    
        <table  class="table table-striped table-bordered dt-responsive nowrap text-center" style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                <thead>
                    <tr>
                        <th>Section</th>
                        <th>Question</th>                    
                    </tr>
                </thead>
                <tbody>
                    <?php $i = 1; ?>
                       <?php $__currentLoopData = $test_question; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <?php
                        ?>
                        <?php $test_section_name = DB::table('test_section')->where('id',$row->test_section)->pluck('test_section_name')->first(); ?>
                        <td><?php echo e($test_section_name); ?></td>
                        <td><?php echo e($row->question); ?></td>                                                                          
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   
                   
                </tbody>
                 
            </table>
        </div>
    </div>
</div>

<style>
    .dt-buttons
    {
        display:none!important;
    }
 </style>   
<!-- end col -->

<?php /**PATH D:\xampp\htdocs\new_zlearn\resources\views/Admin/components/question/view_test_question.blade.php ENDPATH**/ ?>