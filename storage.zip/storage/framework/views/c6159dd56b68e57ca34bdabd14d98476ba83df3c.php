
<div class="col-12">
    <div class="card">
        <div class="card-body"> 
            <div class="row">
                    <div class="col-6 pb-2"> 
                        <h4 class=""> Test Name : <?php echo e($test_level->test_name); ?></a>
                    </div>    
                    <div class="col-6">
                        <input class="form-control mb-5" type="text" id="myInput" placeholder="search section">
                    </div>
                    <?php
                        $test_section = DB::table("test_section")->join('test_tb_section','test_tb_section.test_section_id','=','test_section.id')
                                            ->where('test_tb_section.test_id', $test_level->id)
                                            ->select('test_section.*','test_tb_section.id as test_tb_section_id','test_tb_section.test_id','test_tb_section.test_section_id','test_tb_section.section_question')
                                            ->get();
                    ?>
                    <?php $__currentLoopData = $test_section; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                    <div class="col-3"> 
                        <p class=""> Section: <?php echo e($r->test_section_name); ?></p>
                    </div> 
                    <div class="col-3">
                        <p class=""> Question : <?php echo e($r->section_question); ?></p>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
        </div>
        <table  id="question_table" class="table table-striped table-bordered dt-responsive nowrap text-center" style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                <thead>
                    <tr>
                        <th>Select </th>
                        <th>Section</th>
                        <th>Question</th>                    
                    </tr>
                </thead>
                <form class="" action="<?php echo e(url('save-test-question')); ?>" method="POST">                        
                    <?php echo csrf_field(); ?> 
                    <input type="hidden" name="test_id" value="<?php echo e($test_level->id); ?>" >
                <tbody>
                    <?php $i = 1; ?>
                    <?php $__currentLoopData = $test_chapter; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <?php   
                            $test_question= DB::table("questions")->where("questions.chapter_id",$row->chapter_id)->get();
                            // dd($test_question);
                            
                      ?>
                       <?php $__currentLoopData = $test_question; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    
                    <tr>
                        <?php
                            // $question_level = 
                        ?>
                        <td><input type="checkbox" name="question_id[]" value="<?php echo e($row->id); ?>" ></td>
                        <?php $test_section_name = DB::table('test_section')->where('id',$row->test_section)->pluck('test_section_name')->first(); ?>
                        <td><?php echo e($test_section_name); ?></td>
                        <td><?php echo e($row->question); ?></td>   

                        
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                    
                    
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   
                </tbody>
                <div class="form-group text-center">
                    <div>                        
                        <button type="submit" class="btn btn-primary waves-effect waves-light">
                       Save 
                        </button>
                       
                    </div>
                </div> 
            </form>
            </table>
        </div>
    </div>
</div>

<style>
    .dt-buttons
    {
        display:none!important;
    }
 </style>   
<!-- end col -->
<?php /**PATH D:\xampp\htdocs\new_zlearn\resources\views/Admin/components/question/select_question.blade.php ENDPATH**/ ?>