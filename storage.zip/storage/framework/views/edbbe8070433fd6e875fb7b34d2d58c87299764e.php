<!DOCTYPE html>
<html lang="en"
      dir="ltr">

    <head>
      <?php echo $__env->make('Students.Common.student_head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </head>

    <body class="layout-app ">

        <div class="preloader">
            <div class="sk-chase">
                <div class="sk-chase-dot"></div>
                <div class="sk-chase-dot"></div>
                <div class="sk-chase-dot"></div>
                <div class="sk-chase-dot"></div>
                <div class="sk-chase-dot"></div>
                <div class="sk-chase-dot"></div>
            </div>
        
            <!-- More spinner examples at https://github.com/tobiasahlin/SpinKit/blob/master/examples.html -->
        </div>
        
        <!-- Drawer Layout -->
        
        <div class="mdk-drawer-layout js-mdk-drawer-layout"
             data-push
             data-responsive-width="992px">
            <div class="mdk-drawer-layout__content page-content">
        
                <!-- Header -->
        
                <!-- Navbar -->
        
                <?php echo $__env->make('Students.Common.student_navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        
                <!-- // END Navbar -->
        
                <!-- // END Header -->

                <div class="pt-32pt">
                    <div class="container page__container d-flex flex-column flex-md-row align-items-center text-center text-sm-left">
                        <div class="flex d-flex flex-column flex-sm-row align-items-center mb-24pt mb-md-0">

                            <div class="mb-24pt mb-sm-0 mr-sm-24pt">
                                <h2 class="mb-0">Dashboard</h2>

                                <ol class="breadcrumb p-0 m-0">
                                    <li class="breadcrumb-item"><a href="JavaScript:Void(0);">Dashboard</a></li>

                                    <li class="breadcrumb-item active">

                                        <?php echo e($page_title); ?>


                                    </li>

                                </ol>

                            </div>
                        </div>

                         

                    </div>
                </div>

                <!-- BEFORE Page Content -->

                <!-- // END BEFORE Page Content -->

                <!-- Page Content -->

    <div class="container page__container">
        <div class="page-section">
        
            <div class="row"> 
                <?php $__currentLoopData = $Test_time; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-4 text-center mb-2 height-testcard" >
                        <?php $test_status = DB::table('user_tests')->where('test_id',$list->id)->where('user_id', $user->id)->first(); ?>
                        <?php if($test_status): ?>
                        
                            <form action="javascript:void(0)" method="post" class="w-100"> 
                        <?php else: ?> 
                        <form action="<?php echo e(url('Test-Instraction')); ?>" method="post" class="w-100">
                        
                         
                        <?php endif; ?> 
                        <?php echo csrf_field(); ?>
                           <div class="card" style="height: 100%;">
                              <img class="card-img-top" src="<?php echo e(asset('Student/images/1280_work-station-straight-on-view.jpg')); ?>" alt="Card image cap">
                              <div class="card-body">
                                <h5 class="card-title"><?php echo e($list->test_name); ?></h5>
                                <input type="hidden" name="test_id" value="<?php echo e($list->id); ?>" class="form-control" >
                                <p class="card-text" style="height: 50px;overflow: hidden;"><?php echo e($list->description); ?></p>
                                 <span class="d-flex text-center"><span class="m-auto">Date : <?php echo e($list->exam_date); ?> &nbsp;&nbsp; <?php echo e($list->exam_time); ?></span> </span>
                                 <span class="d-flex text-center"> <span class="m-auto">Time : <?php echo e($list->hours); ?> hr <?php echo e($list->minute); ?> min </span></span>
                                <?php if($test_status): ?>
                                 <span class="btn btn-primary test_done mt-3">Test Completed</span>
                                <?php else: ?>
                                <button class="btn btn-primary mt-3">Start Test</button>
                                <?php endif; ?>  
                              </div>
                            </div>
                        </form>                         
                    </div>                    
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>     
            </div>
        

        </div>
    </div>

    <!-- // END Page Content -->


                <!-- Footer -->

                <!-- <?php echo $__env->make('Students.Common.student_footertext', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> -->

                <!-- // END Footer -->

            </div>

            <!-- // END drawer-layout__content -->

            <!-- Drawer left sidebar start -->

            <?php echo $__env->make('Students.Common.student_sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <!-- // END Drawer sidebar ends -->

        </div>

        <!-- // END Drawer Layout -->

        <?php echo $__env->make('Students.Common.student_footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <script>
            $(document).ready(function()
            {
                $('.test_done').click(function()
                {
                    alert("This Test Already Completed !!!");
                });
            });
        </script>    
    </body>

</html><?php /**PATH D:\xampp\htdocs\new_zlearn\resources\views/Students/Webviews/all_test.blade.php ENDPATH**/ ?>