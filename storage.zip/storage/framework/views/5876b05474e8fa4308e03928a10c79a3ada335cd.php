
<div class="col-12">
    <div class="card">
        <div class="card-body">

            
            
            <div class="col-md-8 m-auto"> 
                <form id="form_two" class="" action="<?php echo e(url('submit-test-two-edit')); ?>" method="POST">                        
                <?php echo csrf_field(); ?> 
                    <div class="form-group row question_count_msg" style="display: none;">
                        <div class="alert alert-danger col-12 " role="alert">
                            Please Enter Correct Question Count
                        </div>
                    </div>

                    <div class="form-group row question_timing_msg" style="display: none;">
                        <div class="alert alert-danger col-12" role="alert">
                            Please Enter Correct Timing
                        </div>
                    </div>                    

                    <div class="form-group row">
                        <label class="col-sm-3 col-form-label">Test Name</label>
                        <div class="col-sm-9">
                            <input type="text" class="form-control" name="test_name"  value="<?php echo e($test->test_name); ?>" readonly/>
                        </div>
                    </div>

                    <?php
                         $hours = $test->hours * 60;
                        $test_duration = $hours + $test->minute
                    ?>

                    <div class="form-group row">
                        <label class="col-sm-3 col-form-label">Total Question </label>
                        <div class="col-sm-3">
                            <input type="text" class="form-control" name="test_total_question"  value="<?php echo e($test->total_question); ?>" readonly>
                        </div>
                        <label class="col-sm-3 col-form-label">Total Minutes</label>
                        <div class="col-sm-3">
                            <input type="text" class="form-control"   value="<?php echo e($test_duration); ?>" readonly/>
                        </div>
                    </div>

                    <input type="hidden" name="test_id" value="<?php echo e($test->id); ?>">
                    <div class="form-group row">
                        <label class="control-label col-sm-3"> Select Chapter</label>
                        <div class="col-sm-9">
                            <select class="select2 form-control select2-multiple" multiple="multiple" name="chapter_id[]" data-placeholder="Choose ..." >
                                 <?php $__currentLoopData = $chapters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                    <option value="<?php echo e($r->chapter_id); ?>"><?php echo e($r->chapter_name); ?></option> 
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                            </select>
                        </div>
                    </div>

                   

                        <?php $__currentLoopData = $test_section; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                        <div class="form-group row">
                            <label class="col-md-3 col-form-label"> <?php echo e($r->test_section_name); ?> </label>
                            <input type="hidden" name="test_tb_section_id[]"  value="<?php echo e($r->test_tb_section_id); ?>">
                            <div class="col-md-4">
                                <input type="text" class="form-control section_time" name="section_time[]"  placeholder="Enter Minute " value="<?php echo e($r->section_time); ?>" readonly/>
                            </div>
                            <div class="col-md-4">
                                <input type="text" class="form-control section_question" name="section_question[]"  placeholder="Enter Section Question" value="<?php echo e($r->section_question); ?> " readonly/>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                        <div class="form-group row">
                            <label class="col-sm-3 col-form-label">Mark Per Question</label>
                            <div class="col-sm-9">
                                <input type="text" class="form-control" name="mark_per_question"  placeholder="Enter Mark Per Question" value="<?php if(isset($test->mark_per_question)): ?><?php echo e($test->mark_per_question); ?><?php endif; ?>" />
                            </div>
                        </div>


                        <?php if($test->test_type_id == 1): ?>
                        <div class="form-group row">
                            <label class="col-sm-3 col-form-label">Exam Date</label>
                            <div class="col-sm-4">
                                <input type="date" class="form-control" name="exam_date" value="<?php if(isset($test->exam_date)): ?><?php echo e($test->exam_date); ?><?php endif; ?>"/>
                            </div>
                            
                            <div class="col-sm-4">
                                <input type="time" class="form-control" name="exam_time" value="<?php if(isset($test->exam_time)): ?><?php echo e($test->exam_time); ?><?php endif; ?>"/>
                            </div>
                           
                        </div> 
                        <?php endif; ?>

                    <div class="form-group text-center mt-5">
                        <div>
                            <button type="reset" class="btn btn-secondary waves-effect m-l-5">
                            Cancel
                            </button>
                            <button type="submit" class="btn btn-primary waves-effect waves-light">
                            Submit
                            </button>
                           
                        </div>

                        <div class="any_message mt-3">
                            <?php if($errors->any()): ?>
                                <div class="alert alert-danger">
                                    <ul>
                                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li><?php echo e($error); ?></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                        </button>
                                    </ul>
                                </div>
                            <?php endif; ?>
                            <?php if(session()->has('alert-danger')): ?>
                                <div class="alert alert-danger">
                                    <?php echo e(session()->get('alert-danger')); ?>

                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                            <?php endif; ?>
                                <?php if(session()->has('alert-success')): ?>
                                <div class="alert alert-success">
                                    <?php echo e(session()->get('alert-success')); ?>

                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<!-- end col -->


<?php /**PATH D:\xampp\htdocs\new_zlearn\resources\views/Admin/components/question/admin_edit_test_two.blade.php ENDPATH**/ ?>