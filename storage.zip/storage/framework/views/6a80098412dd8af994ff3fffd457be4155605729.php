<!DOCTYPE html>
<html lang="en"
    dir="ltr">
    <head>
        <?php echo $__env->make('Students.Common.student_head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        
    </head>
    <body class="layout-app ">
        <div class="preloader">
            <div class="sk-chase">
                <div class="sk-chase-dot"></div>
                <div class="sk-chase-dot"></div>
                <div class="sk-chase-dot"></div>
                <div class="sk-chase-dot"></div>
                <div class="sk-chase-dot"></div>
                <div class="sk-chase-dot"></div>
            </div>
            
            <!-- More spinner examples at https://github.com/tobiasahlin/SpinKit/blob/master/examples.html -->
        </div>
        
        <!-- Drawer Layout -->
        
        <div class="mdk-drawer-layout js-mdk-drawer-layout"
            data-push
            data-responsive-width="992px">
            <div class="mdk-drawer-layout__content page-content">
                
                <!-- Header -->
                
                <!-- Navbar -->
                
                <?php echo $__env->make('Students.Common.student_navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                
                <!-- // END Navbar -->
                
                <!-- // END Header -->
                <div class="pt-32pt">
                    <div class="container page__container d-flex flex-column flex-md-row align-items-center text-center text-sm-left">
                        <div class="flex d-flex flex-column flex-sm-row align-items-center mb-24pt mb-md-0">
                            <div class="mb-24pt mb-sm-0 mr-sm-24pt">
                                <h2 class="mb-0">Dashboard</h2>
                                <ol class="breadcrumb p-0 m-0">
                                    <li class="breadcrumb-item"><a href="#">Student</a></li>
                                    <li class="breadcrumb-item active">
                                        <!-- Basic Information -->
                                        <?php echo e($page_title); ?>

                                    </li>
                                </ol>
                            </div>
                        </div>
                        <!-- <div class="row"
                            role="tablist">
                            <div class="col-auto">
                                <a href="student-my-courses.html"
                                class="btn btn-outline-secondary">My Courses</a>
                            </div>
                        </div> -->
                    </div>
                </div>
                <!-- BEFORE Page Content -->
                <!-- // END BEFORE Page Content -->
                <!-- Page Content -->
                <div class="container page__container">
                    <div class="page-section row">
                    <!-- =================================-->
                      <div class="any_message row col-12">  
                          <?php if($errors->any()): ?>
                          <div class="alert alert-danger col-12">
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                              <span aria-hidden="true">&times;</span>
                            </button>
                              <ul>
                                  <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                      <li><?php echo e($error); ?></li>
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </ul>
                          </div>
                      <?php endif; ?>
                      <?php if(session()->has('alert-danger')): ?>
                        <div class="alert alert-danger col-12">
                          <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                              <span aria-hidden="true">&times;</span>
                            </button>
                            <?php echo e(session()->get('alert-danger')); ?>

                        </div>
                      <?php endif; ?>

                      <?php if(session('success')): ?>
                        <div class="alert alert-success col-12">
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                              <span aria-hidden="true">&times;</span>
                            </button>
                          <?php echo e(session('success')); ?>

                        </div> 
                        <?php endif; ?>
                      </div>  
                    <!-- =================================== -->
                         <form class="form-group col-md-10 m-auto" action="<?php echo e(url('update-password')); ?>" method="POST" enctype="multipart/form-data">
                         <?php echo csrf_field(); ?>                            
                            <div class="form-group row ">
                                <label class="form-label col-md-3 p-2">New Password:</label>
                                <input id="" type="text" class="form-control col-md-9" placeholder="Enter New Password" name="password" required>
                            </div>

                            <div class="form-group row ">
                                <label class="form-label col-md-3 p-2">Confirm Password:</label>
                                <input id="" type="text" class="form-control col-md-9" placeholder="Enter Confirm Password" name="c_password" required>
                            </div>
                         
                            <div class="form-group row">
                                <div class="col-10 m-auto text-right pt-3">
                                    <button type="reset" name="reset" class="btn btn-secondary mr-2">Reset</button>
                                    <button name="submit" class="btn btn-primary">Update</button>
                                </div>
                            </div>   
                        </form>
                    </div>
                </div>
                <!-- // END Page Content -->
                <!-- Footer -->
               <!--  <?php echo $__env->make('Students.Common.student_footertext', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> -->
                <!-- // END Footer -->
            </div>
            <!-- // END drawer-layout__content -->
            <!-- Drawer left sidebar start -->
            <?php echo $__env->make('Students.Common.student_sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- // END Drawer sidebar ends -->
        </div>
        <!-- // END Drawer Layout -->
        <?php echo $__env->make('Students.Common.student_footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo toastr_js(); ?>
        <?php echo app('toastr')->render(); ?>
    </body>
</html><?php /**PATH D:\xampp\htdocs\new_zlearn\resources\views/Students/Webviews/edit_password.blade.php ENDPATH**/ ?>