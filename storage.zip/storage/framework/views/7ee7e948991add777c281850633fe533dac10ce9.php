  <!-- jQuery -->
  <script src="<?php echo e(asset('Student/vendor/jquery.min.js')); ?>"></script>

  <!-- Bootstrap -->
  <script src="<?php echo e(asset('Student/vendor/popper.min.js')); ?>"></script>
  <script src="<?php echo e(asset('Student/vendor/bootstrap.min.js')); ?>"></script>

  <!-- Perfect Scrollbar -->
  <script src="<?php echo e(asset('Student/vendor/perfect-scrollbar.min.js')); ?>"></script>

  <!-- DOM Factory -->
  <script src="<?php echo e(asset('Student/vendor/dom-factory.js')); ?>"></script>

  <!-- MDK -->
  <script src="<?php echo e(asset('Student/vendor/material-design-kit.js')); ?>"></script>

  <!-- App JS -->
  <script src="<?php echo e(asset('Student/js/app.js')); ?>"></script>

  <!-- Preloader -->
  <script src="<?php echo e(asset('Student/js/preloader.js')); ?>"></script>

  <!-- Global Settings -->
  <script src="<?php echo e(asset('Student/js/settings.js')); ?>"></script>

  <!-- Flatpickr -->
  <script src="<?php echo e(asset('Student/vendor/flatpickr/flatpickr.min.js')); ?>"></script>
  <script src="<?php echo e(asset('Student/js/flatpickr.js')); ?>"></script>

  <!-- Moment.js -->
  <script src="<?php echo e(asset('Student/vendor/moment.min.js')); ?>"></script>
  <script src="<?php echo e(asset('Student/vendor/moment-range.js')); ?>"></script>

  <!-- Chart.js -->
  <script src="<?php echo e(asset('Student/vendor/Chart.min.js')); ?>"></script>
  <script src="<?php echo e(asset('Student/js/chartjs.js')); ?>"></script>

  <!-- Chart.js Samples -->
  <script src="<?php echo e(asset('Student/js/page.student-dashboard.js')); ?>"></script>

  <!-- List.js -->
  <script src="<?php echo e(asset('Student/vendor/list.min.js')); ?>"></script>
  <script src="<?php echo e(asset('Student/js/list.js')); ?>"></script>

  <!-- Tables -->
  <script src="<?php echo e(asset('Student/js/toggle-check-all.js')); ?>"></script>
  <script src="<?php echo e(asset('Student/js/check-selected-row.js')); ?>"></script><?php /**PATH D:\xampp\htdocs\new_zlearn\resources\views/Students/common/student_footer.blade.php ENDPATH**/ ?>